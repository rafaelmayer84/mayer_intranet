#!/usr/bin/env php
<?php

/**
 * ═══════════════════════════════════════════════════════════════
 * NEXO - Rollback do Patch do Webhook
 * ═══════════════════════════════════════════════════════════════
 * 
 * Executa via SSH:
 * php rollback_webhook.php
 * 
 * Funcionalidade:
 * - Lista backups disponíveis
 * - Permite escolher qual backup restaurar
 * - Restaura arquivo original
 * - Valida sintaxe após restauração
 */

class WebhookRollback
{
    private string $controllerPath;
    private string $backupDir;
    
    public function __construct()
    {
        $this->controllerPath = __DIR__ . '/app/Http/Controllers/Nexo/NexoWebhookController.php';
        $this->backupDir = __DIR__ . '/app/Http/Controllers/Nexo';
    }
    
    public function run(): int
    {
        echo "\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "NEXO - Rollback do Patch do Webhook\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "\n";
        
        // Listar backups disponíveis
        $backups = $this->listBackups();
        
        if (empty($backups)) {
            echo "❌ Nenhum backup encontrado!\n";
            echo "   Diretório: {$this->backupDir}\n";
            echo "   Padrão: NexoWebhookController.php.backup.*\n\n";
            return 1;
        }
        
        echo "Backups disponíveis:\n\n";
        
        foreach ($backups as $index => $backup) {
            $num = $index + 1;
            $date = date('d/m/Y H:i:s', filemtime($backup['path']));
            $size = number_format(filesize($backup['path']) / 1024, 2);
            
            echo "  [$num] {$backup['filename']}\n";
            echo "      Data: $date\n";
            echo "      Tamanho: {$size} KB\n\n";
        }
        
        echo "Escolha o backup para restaurar (1-" . count($backups) . ") ou 0 para cancelar: ";
        $choice = trim(fgets(STDIN));
        
        if ($choice === '0' || $choice === '') {
            echo "\nOperação cancelada.\n\n";
            return 0;
        }
        
        $index = (int)$choice - 1;
        
        if (!isset($backups[$index])) {
            echo "\n❌ Opção inválida!\n\n";
            return 1;
        }
        
        $selectedBackup = $backups[$index];
        
        echo "\n";
        echo "Restaurando backup:\n";
        echo "  {$selectedBackup['filename']}\n";
        echo "\n";
        echo "ATENÇÃO: Isso irá SUBSTITUIR o arquivo atual!\n";
        echo "Confirma? (s/N): ";
        
        $confirm = trim(fgets(STDIN));
        
        if (strtolower($confirm) !== 's') {
            echo "\nOperação cancelada.\n\n";
            return 0;
        }
        
        // Fazer backup do estado atual antes de restaurar
        $currentBackup = $this->controllerPath . '.before-rollback.' . date('Y-m-d_His');
        
        if (!copy($this->controllerPath, $currentBackup)) {
            echo "❌ ERRO: Não foi possível fazer backup do estado atual!\n";
            return 1;
        }
        
        echo "✓ Backup do estado atual criado\n";
        echo "  $currentBackup\n\n";
        
        // Restaurar backup selecionado
        if (!copy($selectedBackup['path'], $this->controllerPath)) {
            echo "❌ ERRO: Não foi possível restaurar backup!\n";
            return 1;
        }
        
        echo "✓ Backup restaurado\n\n";
        
        // Validar sintaxe
        echo "Validando sintaxe...\n";
        
        $output = [];
        $returnCode = 0;
        
        exec("php -l " . escapeshellarg($this->controllerPath) . " 2>&1", $output, $returnCode);
        
        if ($returnCode !== 0) {
            echo "❌ Sintaxe inválida após restauração:\n";
            foreach ($output as $line) {
                echo "   $line\n";
            }
            echo "\nRestaurando estado anterior...\n";
            copy($currentBackup, $this->controllerPath);
            return 1;
        }
        
        echo "✓ Sintaxe válida\n\n";
        
        echo "═══════════════════════════════════════════════════════════\n";
        echo "✅ ROLLBACK CONCLUÍDO COM SUCESSO!\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "\n";
        echo "Arquivo restaurado para:\n";
        echo "  {$selectedBackup['filename']}\n";
        echo "\n";
        echo "Backup do estado anterior salvo em:\n";
        echo "  " . basename($currentBackup) . "\n";
        echo "\n";
        
        return 0;
    }
    
    private function listBackups(): array
    {
        $backups = [];
        $pattern = $this->backupDir . '/NexoWebhookController.php.backup.*';
        
        foreach (glob($pattern) as $file) {
            if (is_file($file)) {
                $backups[] = [
                    'path' => $file,
                    'filename' => basename($file)
                ];
            }
        }
        
        // Ordenar por data (mais recente primeiro)
        usort($backups, function($a, $b) {
            return filemtime($b['path']) - filemtime($a['path']);
        });
        
        return $backups;
    }
}

// ═══════════════════════════════════════════════════════════════
// Execução
// ═══════════════════════════════════════════════════════════════

if (php_sapi_name() !== 'cli') {
    die("Este script deve ser executado via CLI\n");
}

$rollback = new WebhookRollback();
$exitCode = $rollback->run();

exit($exitCode);
