# NEXO - WhatsApp Lead Tracking (Solução 3)

## 📋 VISÃO GERAL

Sistema de rastreamento de origem de leads WhatsApp, capturando GCLID, FBCLID e UTMs para análise de ROI de campanhas de marketing.

**Características:**
- ✅ Invisível para o usuário
- ✅ Automático (sem intervenção manual)
- ✅ Integrado ao NEXO existente
- ✅ Compatível 100% com sistema atual

---

## 🔧 COMPONENTES

### 1. JavaScript (Frontend)
**Arquivo:** `whatsapp-tracking.js`  
**Instalação:** WPCode no WordPress

### 2. Migration (Banco de Dados)
**Arquivo:** `create_whatsapp_tracking_tables.php`  
**Cria:** `leads_tracking` + `wa_conversation_sources`

### 3. Controller (Backend)
**Arquivo:** `NexoTrackingController.php`  
**Endpoint:** `/nexo/api/pre-track-whatsapp-lead`

### 4. Webhook Patch (Backend)
**Arquivo:** `webhook_patch.php`  
**Modifica:** `NexoWebhookController::handleIncomingMessage()`

### 5. Rotas (Backend)
**Arquivo:** `routes_api.php`  
**Adiciona:** Rota pública para pre-tracking

### 6. Cleanup Command (Backend)
**Arquivo:** `CleanupTrackingCommand.php`  
**Comando:** `php artisan nexo:cleanup-tracking`

---

## 📦 INSTALAÇÃO PASSO A PASSO

### PASSO 1: Banco de Dados

```bash
# 1. Copiar migration para Laravel
cp create_whatsapp_tracking_tables.php \
   intranet/database/migrations/2026_02_09_000001_create_whatsapp_tracking_tables.php

# 2. Executar migration
cd intranet
php artisan migrate

# 3. Verificar tabelas criadas
php artisan db:show --table=leads_tracking
php artisan db:show --table=wa_conversation_sources
```

**Validação:**
```sql
-- Deve retornar estrutura das tabelas
DESCRIBE leads_tracking;
DESCRIBE wa_conversation_sources;
```

---

### PASSO 2: Controller de Tracking

```bash
# 1. Criar diretório se não existe
mkdir -p intranet/app/Http/Controllers/Nexo

# 2. Copiar controller
cp NexoTrackingController.php \
   intranet/app/Http/Controllers/Nexo/NexoTrackingController.php

# 3. Verificar sintaxe
php -l intranet/app/Http/Controllers/Nexo/NexoTrackingController.php
```

---

### PASSO 3: Rotas

```bash
# Editar arquivo de rotas
nano intranet/routes/api.php
```

**Adicionar no final do arquivo:**

```php
// ════════════════════════════════════════════════════════════
// NEXO WhatsApp Tracking
// ════════════════════════════════════════════════════════════

use App\Http\Controllers\Nexo\NexoTrackingController;

Route::post('nexo/api/pre-track-whatsapp-lead', [
    NexoTrackingController::class, 
    'preTrackWhatsAppLead'
])
->middleware('throttle:60,1') // Rate limit: 60/min
->name('nexo.pre-track-whatsapp');
```

**Validação:**

```bash
# Listar rotas
php artisan route:list | grep nexo

# Deve aparecer:
# POST | nexo/api/pre-track-whatsapp-lead | nexo.pre-track-whatsapp
```

---

### PASSO 4: Patch do Webhook (AUTOMÁTICO)

**⚡ Script executável via SSH - Instalação automática**

```bash
# 1. Copiar script para raiz do projeto Laravel
cp patch_webhook.php intranet/patch_webhook.php
cd intranet

# 2. Dar permissão de execução
chmod +x patch_webhook.php

# 3. Executar em modo dry-run (visualizar sem modificar)
php patch_webhook.php --dry-run

# 4. Executar patch (faz backup automático)
php patch_webhook.php
```

**O script faz automaticamente:**
- ✅ Localiza `WaConversation::create()` no código
- ✅ Cria backup com timestamp (`.backup.YYYY-MM-DD_HHmmss`)
- ✅ Insere código de tracking após criação da conversa
- ✅ Adiciona método `normalizePhoneForTracking()` na classe
- ✅ Valida sintaxe PHP após modificação
- ✅ Rollback automático em caso de erro

**Saída esperada:**

```
═══════════════════════════════════════════════════════════
NEXO - Patch Automático do Webhook
═══════════════════════════════════════════════════════════

Validando arquivo...
✓ Arquivo validado
  Caminho: /var/www/intranet/app/Http/Controllers/Nexo/NexoWebhookController.php
  Tamanho: 12,345 bytes

Verificando se já foi patcheado...
✓ Arquivo NÃO está patcheado (pode continuar)

Criando backup...
✓ Backup criado
  /var/www/intranet/app/Http/Controllers/Nexo/NexoWebhookController.php.backup.2026-02-09_210530

Aplicando patch...
✓ Encontrado ponto de inserção (WaConversation::create)
✓ Patch aplicado
  Bytes adicionados: +2,847

Validando sintaxe PHP...
✓ Sintaxe válida

═══════════════════════════════════════════════════════════
✅ PATCH APLICADO COM SUCESSO!
═══════════════════════════════════════════════════════════

Backup salvo em:
  /var/www/intranet/app/Http/Controllers/Nexo/NexoWebhookController.php.backup.2026-02-09_210530

Para reverter o patch:
  php rollback_webhook.php
```

---

### PASSO 4.1: Rollback (se necessário)

```bash
# Copiar script de rollback
cp rollback_webhook.php intranet/rollback_webhook.php
cd intranet

# Executar rollback interativo
php rollback_webhook.php
```

**O script de rollback:**
- Lista todos os backups disponíveis
- Permite escolher qual versão restaurar
- Faz backup do estado atual antes de restaurar
- Valida sintaxe após restauração

---

### PASSO 5: Comando de Cleanup

```bash
# 1. Criar diretório se não existe
mkdir -p intranet/app/Console/Commands

# 2. Copiar command
cp CleanupTrackingCommand.php \
   intranet/app/Console/Commands/CleanupTrackingCommand.php

# 3. Testar comando (dry-run)
php artisan nexo:cleanup-tracking --dry-run

# 4. Adicionar ao cron (executar diariamente)
# Editar: intranet/app/Console/Kernel.php
```

**Adicionar em `schedule()`:**

```php
$schedule->command('nexo:cleanup-tracking')
         ->daily()
         ->at('03:00');
```

---

### PASSO 6: JavaScript no Site

**WordPress → Plugins → WPCode → Add Snippet**

1. **Tipo:** Custom Code (JavaScript)
2. **Nome:** NEXO WhatsApp Tracking
3. **Localização:** Footer
4. **Páginas:** All Pages
5. **Código:** Copiar conteúdo de `whatsapp-tracking.js`

**Configuração importante:**

```javascript
const CONFIG = {
    // ⚠️ AJUSTAR URL conforme seu ambiente
    apiUrl: 'https://intranet.mayeradvogados.adv.br/nexo/api/pre-track-whatsapp-lead',
    
    timeout: 1000,
    storageDays: 30,
    storageKey: 'nexo_tracking_data'
};
```

**Ativar snippet e publicar.**

---

## ✅ VALIDAÇÃO PÓS-INSTALAÇÃO

### Teste 1: Endpoint respondendo

```bash
curl -X POST https://intranet.mayeradvogados.adv.br/nexo/api/pre-track-whatsapp-lead \
  -H "Content-Type: application/json" \
  -d '{
    "phone": "+5547999999999",
    "gclid": "test_123",
    "utm_source": "google"
  }'

# Resposta esperada:
# {"success":true,"tracking_id":1}
```

### Teste 2: Registro criado no banco

```sql
SELECT * FROM leads_tracking 
WHERE phone = '+5547999999999' 
ORDER BY created_at DESC 
LIMIT 1;

-- Deve retornar o registro criado
```

### Teste 3: JavaScript capturando dados

1. Acesse: `https://mayeradvogados.adv.br/?gclid=test_456&utm_source=google`
2. Abra DevTools (F12) → Console
3. Digite: `localStorage.getItem('nexo_tracking_data')`
4. Deve retornar JSON com os dados

### Teste 4: Fluxo completo (E2E)

1. Acesse site com UTMs: `?utm_source=teste&utm_campaign=instalacao`
2. Clique no botão WhatsApp
3. Envie primeira mensagem
4. Verificar banco:

```sql
-- Verificar tracking criado
SELECT * FROM leads_tracking 
WHERE utm_campaign = 'instalacao';

-- Verificar conversa criada
SELECT * FROM wa_conversations 
WHERE phone LIKE '%999999999%' 
ORDER BY created_at DESC LIMIT 1;

-- Verificar origem vinculada
SELECT cs.* 
FROM wa_conversation_sources cs
JOIN wa_conversations wc ON cs.conversation_id = wc.id
WHERE wc.phone LIKE '%999999999%';
```

---

## 📊 QUERIES ÚTEIS

### Conversões por origem (Google Ads)

```sql
SELECT 
    COUNT(*) as total_conversoes,
    DATE(wc.created_at) as data
FROM wa_conversations wc
JOIN wa_conversation_sources wcs ON wcs.conversation_id = wc.id
WHERE wcs.gclid IS NOT NULL
GROUP BY DATE(wc.created_at)
ORDER BY data DESC;
```

### ROI por campanha

```sql
SELECT 
    wcs.utm_campaign,
    COUNT(DISTINCT wc.id) as leads,
    COUNT(DISTINCT wc.linked_cliente_id) as conversoes_cliente,
    ROUND(COUNT(DISTINCT wc.linked_cliente_id) * 100.0 / COUNT(DISTINCT wc.id), 2) as taxa_conversao
FROM wa_conversations wc
JOIN wa_conversation_sources wcs ON wcs.conversation_id = wc.id
WHERE wcs.utm_campaign IS NOT NULL
GROUP BY wcs.utm_campaign
ORDER BY leads DESC;
```

### Tracking não matchado (possíveis problemas)

```sql
SELECT 
    phone,
    gclid,
    utm_source,
    created_at,
    TIMESTAMPDIFF(HOUR, created_at, NOW()) as horas_sem_match
FROM leads_tracking
WHERE matched_at IS NULL
ORDER BY created_at DESC;
```

---

## 🔧 TROUBLESHOOTING

### Problema: Endpoint retorna 404

**Causa:** Rota não registrada

**Solução:**
```bash
php artisan route:clear
php artisan route:cache
php artisan route:list | grep nexo
```

### Problema: JavaScript não captura dados

**Causa:** URL da API incorreta

**Solução:**
1. Verificar `apiUrl` em `whatsapp-tracking.js`
2. Testar endpoint com cURL
3. Verificar console do navegador (F12)

### Problema: Tracking não vincula à conversa

**Causa:** Normalização de telefone diferente

**Solução:**
```sql
-- Verificar formato do telefone em ambas as tabelas
SELECT phone FROM leads_tracking;
SELECT phone FROM wa_conversations;

-- Devem estar no mesmo formato: +5547XXXXXXXXX
```

### Problema: Registros acumulando em leads_tracking

**Causa:** Cleanup não executando

**Solução:**
```bash
# Executar manualmente
php artisan nexo:cleanup-tracking

# Verificar cron
php artisan schedule:list

# Testar schedule
php artisan schedule:run
```

---

## 📈 MONITORAMENTO

### Métricas diárias

```sql
-- Tracking criados hoje
SELECT COUNT(*) FROM leads_tracking 
WHERE DATE(created_at) = CURDATE();

-- Conversões hoje
SELECT COUNT(*) FROM wa_conversation_sources 
WHERE DATE(created_at) = CURDATE();

-- Taxa de conversão (tracking → conversa)
SELECT 
    COUNT(DISTINCT lt.id) as trackings,
    COUNT(DISTINCT lt.matched_at) as matches,
    ROUND(COUNT(DISTINCT lt.matched_at) * 100.0 / COUNT(DISTINCT lt.id), 2) as taxa_match
FROM leads_tracking lt
WHERE DATE(lt.created_at) = CURDATE();
```

### Logs importantes

```bash
# Tracking salvos
tail -f storage/logs/laravel.log | grep "NEXO Tracking: Origem salva"

# Erros de tracking
tail -f storage/logs/laravel.log | grep "NEXO Tracking Error"

# Cleanup executado
tail -f storage/logs/laravel.log | grep "NEXO Tracking Cleanup"
```

---

## 🚀 PRÓXIMOS PASSOS

1. **Integração com Google Analytics:**
   - Enviar eventos de conversão
   - Rastrear funil completo

2. **Dashboard de ROI:**
   - Visualização de conversões por campanha
   - Gráficos de performance

3. **Alertas automáticos:**
   - Queda na taxa de conversão
   - Campanhas com baixo ROI

4. **Enriquecimento de dados:**
   - Capturar IP, user agent
   - Geolocalização aproximada

---

## 📞 SUPORTE

Em caso de dúvidas ou problemas:

1. Verificar logs: `storage/logs/laravel.log`
2. Executar queries de validação
3. Testar endpoint com cURL
4. Verificar DevTools do navegador
