#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# NEXO - Remove Duplicações de Rotas
# ═══════════════════════════════════════════════════════════════

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "NEXO - Removendo duplicações em routes/api.php"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Backup
cp routes/api.php routes/api.php.backup.$(date +%Y%m%d_%H%M%S)
echo "✓ Backup criado"

# Remove linhas duplicadas do NexoTrackingController
# Mantém apenas a PRIMEIRA ocorrência

# Criar arquivo temporário
temp_file=$(mktemp)

# Variáveis de controle
found_use=0
found_route=0
in_route_block=0

while IFS= read -r line; do
    # Detecta use NexoTrackingController
    if [[ "$line" =~ "use App\\Http\\Controllers\\Nexo\\NexoTrackingController" ]]; then
        if [ $found_use -eq 0 ]; then
            echo "$line" >> "$temp_file"
            found_use=1
        else
            echo "  [REMOVIDO] use NexoTrackingController (duplicado)"
            continue
        fi
    # Detecta início do Route::post para nexo/api/pre-track-whatsapp-lead
    elif [[ "$line" =~ "Route::post('nexo/api/pre-track-whatsapp-lead'" ]] || \
         [[ "$line" =~ 'Route::post("nexo/api/pre-track-whatsapp-lead"' ]]; then
        if [ $found_route -eq 0 ]; then
            echo "$line" >> "$temp_file"
            found_route=1
            in_route_block=1
        else
            echo "  [REMOVIDO] Route::post nexo/api/pre-track-whatsapp-lead (duplicado)"
            in_route_block=1
            continue
        fi
    # Se está dentro de bloco de rota duplicado, pular até fechar
    elif [ $in_route_block -eq 1 ] && [ $found_route -gt 1 ]; then
        # Continua pulando até encontrar ;
        if [[ "$line" =~ ";" ]]; then
            in_route_block=0
        fi
        continue
    # Detecta linhas internas da rota (se for duplicata)
    elif [ $in_route_block -eq 1 ] && [ $found_route -eq 0 ]; then
        echo "$line" >> "$temp_file"
        if [[ "$line" =~ ";" ]]; then
            in_route_block=0
        fi
    # Detecta fim de bloco de rota (primeira ocorrência)
    elif [ $in_route_block -eq 1 ]; then
        echo "$line" >> "$temp_file"
        if [[ "$line" =~ ";" ]]; then
            in_route_block=0
        fi
    else
        echo "$line" >> "$temp_file"
    fi
    
done < routes/api.php

# Substituir arquivo original
mv "$temp_file" routes/api.php

echo "✓ Duplicações removidas"
echo ""
echo "Linhas removidas:"
echo "  - use NexoTrackingController duplicados: $(expr $found_use - 1)"
echo "  - Route::post duplicados: $(expr $found_route - 1)"
echo ""
echo "Para verificar:"
echo "  grep -n 'NexoTrackingController' routes/api.php"
echo ""
echo "Para reverter:"
echo "  cp routes/api.php.backup.* routes/api.php"
echo ""
