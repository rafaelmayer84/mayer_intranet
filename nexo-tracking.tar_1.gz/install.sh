#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# NEXO WhatsApp Tracking - Instalação Automática
# ═══════════════════════════════════════════════════════════════

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "NEXO - WhatsApp Tracking - Instalação Automática"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ────────────────────────────────────────────────────────────
# 1. Migration
# ────────────────────────────────────────────────────────────

echo "PASSO 1: Copiando migration..."
cp create_whatsapp_tracking_tables.php \
   database/migrations/2026_02_09_000001_create_whatsapp_tracking_tables.php

if [ $? -eq 0 ]; then
    echo "✓ Migration copiada"
else
    echo "✗ ERRO ao copiar migration"
    exit 1
fi

echo ""
echo "Executando migration..."
php artisan migrate --force

if [ $? -eq 0 ]; then
    echo "✓ Tabelas criadas"
else
    echo "✗ ERRO na migration"
    exit 1
fi

# ────────────────────────────────────────────────────────────
# 2. Controller
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 2: Copiando controller..."
mkdir -p app/Http/Controllers/Nexo
cp NexoTrackingController.php app/Http/Controllers/Nexo/

if [ $? -eq 0 ]; then
    echo "✓ Controller copiado"
else
    echo "✗ ERRO ao copiar controller"
    exit 1
fi

# ────────────────────────────────────────────────────────────
# 3. Rotas
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 3: Adicionando rotas..."
echo "" >> routes/api.php
cat routes_api.php >> routes/api.php

echo "✓ Rotas adicionadas"

php artisan route:clear
php artisan route:cache

# ────────────────────────────────────────────────────────────
# 4. Cleanup Command
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 4: Copiando cleanup command..."
mkdir -p app/Console/Commands
cp CleanupTrackingCommand.php app/Console/Commands/

echo "✓ Cleanup command copiado"

# ────────────────────────────────────────────────────────────
# 5. Scripts executáveis
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 5: Copiando scripts..."
cp patch_webhook.php .
cp rollback_webhook.php .
chmod +x patch_webhook.php rollback_webhook.php

echo "✓ Scripts copiados"

# ────────────────────────────────────────────────────────────
# Concluído
# ────────────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ INSTALAÇÃO CONCLUÍDA!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "Próximos passos:"
echo ""
echo "1. Aplicar patch no webhook:"
echo "   php patch_webhook.php --dry-run"
echo "   php patch_webhook.php"
echo ""
echo "2. Instalar JavaScript no WordPress (WPCode)"
echo "   Arquivo: whatsapp-tracking.js"
echo ""
echo "Documentação completa: INSTALACAO.md"
echo ""

