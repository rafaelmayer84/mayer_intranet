<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Processo;
use App\Models\ContaReceber;
use App\Models\Advogado;
use App\Models\Configuracao;
use App\Models\Movimento;
use App\Services\DashboardFinanceProdService;
use App\Services\KpiService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DashboardController extends Controller
{
    protected $kpiService;
    protected $dashboardFinance;
    
    public function __construct(KpiService $kpiService, DashboardFinanceProdService $dashboardFinance)
    {
        $this->kpiService = $kpiService;
        $this->dashboardFinance = $dashboardFinance;
    }
    
    /**
     * Classifica uma conta como PF, PJ ou Outro baseado na descrição
     */
    private function classificarConta($descricao)
    {
        $descricao = strtoupper($descricao);
        
        // Verifica se é misto (PF/PJ)
        if (strpos($descricao, 'PF/PJ') !== false || strpos($descricao, 'PJ/PF') !== false) {
            return 'misto';
        }
        
        // Verifica se é PJ
        if (strpos($descricao, ' PJ') !== false || strpos($descricao, 'PESSOA JURÍDICA') !== false || strpos($descricao, 'PESSOA JURIDICA') !== false) {
            return 'pj';
        }
        
        // Verifica se é PF
        if (strpos($descricao, ' PF') !== false || strpos($descricao, 'PESSOA FÍSICA') !== false || strpos($descricao, 'PESSOA FISICA') !== false) {
            return 'pf';
        }
        
        // Verifica se é despesa/débito/custas
        if (strpos($descricao, 'DESPESA') !== false || strpos($descricao, 'CUSTAS') !== false || 
            strpos($descricao, 'REEMBOLSO') !== false || substr(trim($descricao), 0, 2) === 'D ') {
            return 'despesa';
        }
        
        return 'outro';
    }
    
    /**
     * Visão Gerencial - Dashboard principal com metas
     */
    public function visaoGerencial(Request $request)
    {
        $user = Auth::user();
        // Sem restrição de role - segurança será implementada posteriormente

        $ano = (int) $request->get('ano', date('Y'));
        $mes = (int) $request->get('mes', date('n'));
        $mes = max(1, min(12, $mes));

        $dashboardData = $this->dashboardFinance->getDashboardData($ano, $mes);

        // Opções fixas conforme escopo atual do projeto
        $anosDisponiveis = [2020, 2021, 2022, 2023, 2024, 2025, 2026];
        $mesesDisponiveis = [
            1 => 'Jan', 2 => 'Fev', 3 => 'Mar', 4 => 'Abr', 5 => 'Mai', 6 => 'Jun',
            7 => 'Jul', 8 => 'Ago', 9 => 'Set', 10 => 'Out', 11 => 'Nov', 12 => 'Dez'
        ];

        return view('dashboard.visao-gerencial', compact('ano', 'mes', 'dashboardData', 'anosDisponiveis', 'mesesDisponiveis'));
    }

    /**
     * API: payload completo da visão gerencial (para atualização por filtros).
     */
    public function visaoGerencialData(Request $request)
    {
        $user = Auth::user();
        // Sem restrição de role - segurança será implementada posteriormente

        $ano = (int) $request->get('ano', date('Y'));
        $mes = (int) $request->get('mes', date('n'));
        $mes = max(1, min(12, $mes));

        return response()->json($this->dashboardFinance->getDashboardData($ano, $mes));
    }


    // Endpoint interno para consumo de KPIs via JS/integrações
    public function getKpisFinanceiros(\Illuminate\Http\Request $request)
    {
        $ano = (int) $request->get('ano', date('Y'));
        $mes = (int) $request->get('mes', date('n'));

        $data = $this->dashboardFinance->getDashboardData($ano, $mes);

        return response()->json($data);
    }

    /**
     * Exportação simples (CSV) da competência atual.
     *
     * Observação: PDF fica via "Imprimir" (window.print) no front, para evitar dependência.
     */
    public function visaoGerencialExport(Request $request): StreamedResponse
    {
        $user = Auth::user();
        // Sem restrição de role - segurança será implementada posteriormente

        $ano = (int) $request->get('ano', date('Y'));
        $mes = (int) $request->get('mes', date('n'));
        $mes = max(1, min(12, $mes));

        $data = $this->dashboardFinance->getDashboardData($ano, $mes);
        $filename = "visao-gerencial-{$ano}-" . str_pad((string) $mes, 2, '0', STR_PAD_LEFT) . ".csv";

        $response = new StreamedResponse(function () use ($data) {
            $out = fopen('php://output', 'w');
            fputcsv($out, ['Ano', $data['ano'], 'Mês', $data['mes']]);
            fputcsv($out, []);

            fputcsv($out, ['Resumo Executivo']);
            fputcsv($out, ['Receita Total', $data['resumoExecutivo']['receitaTotal'], 'Meta', $data['resumoExecutivo']['receitaMeta'], 'Trend(%)', $data['resumoExecutivo']['receitaTrend']]);
            fputcsv($out, ['Despesas Total', $data['resumoExecutivo']['despesasTotal'], 'Meta', $data['resumoExecutivo']['despesasMeta'], 'Trend(%)', $data['resumoExecutivo']['despesasTrend']]);
            fputcsv($out, ['Resultado Líquido', $data['resumoExecutivo']['resultadoLiquido'], 'Meta', $data['resumoExecutivo']['resultadoMeta'], 'Trend(%)', $data['resumoExecutivo']['resultadoTrend']]);
            fputcsv($out, ['Margem Líquida(%)', $data['resumoExecutivo']['margemLiquida'], 'Meta(%)', $data['resumoExecutivo']['margemMeta'], 'Trend(%)', $data['resumoExecutivo']['margemTrend']]);
            fputcsv($out, []);

            fputcsv($out, ['Saúde Financeira']);
            fputcsv($out, ['Contas em Atraso', $data['saudeFinanceira']['contasAtraso'], '% Receita', $data['saudeFinanceira']['contasAtrasoPercent'], 'Trend(%)', $data['saudeFinanceira']['contasAtrasoTrend']]);
            fputcsv($out, ['Dias Médio Atraso', $data['saudeFinanceira']['diasMedioAtraso'], 'Meta', $data['saudeFinanceira']['diasMedioAtrasoMeta'], 'Trend(dias)', $data['saudeFinanceira']['diasMedioAtrasoTrend']]);
            fputcsv($out, ['Taxa Cobrança(%)', $data['saudeFinanceira']['taxaCobranca'], 'Meta(%)', $data['saudeFinanceira']['taxaCobrancaMeta'], 'Trend(%)', $data['saudeFinanceira']['taxaCobrancaTrend']]);
            fputcsv($out, []);

            fputcsv($out, ['Despesas por Rubrica']);
            fputcsv($out, ['Rubrica', 'Valor', 'Meta', 'Trend(%)']);
            foreach ($data['despesasRubrica'] as $r) {
                fputcsv($out, [$r['rubrica'], $r['valor'], $r['meta'], $r['trend']]);
            }
            fputcsv($out, []);

            fputcsv($out, ['Contas em Atraso (Top 10)']);
            fputcsv($out, ['Cliente', 'Valor', 'Dias Atraso', 'Status']);
            foreach ($data['contasAtrasoLista'] as $c) {
                fputcsv($out, [$c['cliente'], $c['valor'], $c['diasAtraso'], $c['status']]);
            }

            fclose($out);
        });

        $response->headers->set('Content-Type', 'text/csv; charset=UTF-8');
        $response->headers->set('Content-Disposition', "attachment; filename=\"{$filename}\"");
        return $response;
    }
    
    /**
     * Configurar Metas
     */
    public function configurarMetas(Request $request)
    {
        $ano = $request->get('ano', date('Y'));
        
        // Buscar metas mensais
        $metasPF = $this->getMetasMensais('meta_pf', $ano);
        $metasPJ = $this->getMetasMensais('meta_pj', $ano);
        $metasDespesas = $this->getMetasMensais('meta_despesas', $ano);
        $metasResultado = $this->getMetasMensais('meta_resultado', $ano);
        $metasMargem = $this->getMetasMensais('meta_margem', $ano);
        $metasDiasAtraso = $this->getMetasMensais('meta_dias_atraso', $ano);
        $metasTaxaCobranca = $this->getMetasMensais('meta_taxa_cobranca', $ano);
        
        $metas = [
            'pf' => $metasPF,
            'pj' => $metasPJ,
            'despesas' => $metasDespesas,
            'resultado' => $metasResultado,
            'margem' => $metasMargem,
            'dias_atraso' => $metasDiasAtraso,
            'taxa_cobranca' => $metasTaxaCobranca,
            'avaliacoes' => Configuracao::get('meta_avaliacoes_google', 250),
            'contratos' => Configuracao::get('meta_contratos', 400000),
            'inadimplencia' => Configuracao::get('meta_inadimplencia', 1000),
            'clientes' => Configuracao::get('meta_clientes', 80),
        ];
        
        return view('dashboard.configurar-metas', compact('ano', 'metas'));
    }
    
    /**
     * Atualizar metas via PUT (AJAX) - Salva cada seção independentemente
     */
    public function updateMetas(Request $request)
    {
        $ano = $request->get('ano', date('Y'));
        $tipo = $request->get('tipo', 'pf');
        
        \Log::info('updateMetas chamado', ['ano' => $ano, 'tipo' => $tipo, 'dados' => $request->all()]);
        
        try {
            if ($tipo === 'pf') {
                // Salvar metas PF
                for ($mes = 1; $mes <= 12; $mes++) {
                    $valor = $request->get("meta_pf[$mes]", 0);
                    Configuracao::set("meta_pf_{$ano}_{$mes}", $valor);
                }
            } elseif ($tipo === 'pj') {
                // Salvar metas PJ
                for ($mes = 1; $mes <= 12; $mes++) {
                    $valor = $request->get("meta_pj[$mes]", 0);
                    Configuracao::set("meta_pj_{$ano}_{$mes}", $valor);
                }
            } elseif ($tipo === 'despesas') {
                // Salvar metas de despesas
                for ($mes = 1; $mes <= 12; $mes++) {
                    $valor = $request->get("meta_despesas[$mes]", 0);
                    Configuracao::set("meta_despesas_{$ano}_{$mes}", $valor);
                }
            } elseif ($tipo === 'resultado') {
                for ($mes = 1; $mes <= 12; $mes++) {
                    Configuracao::set("meta_resultado_{$ano}_{$mes}", $request->get("meta_resultado_{$mes}", 0));
                }
            } elseif ($tipo === 'margem') {
                for ($mes = 1; $mes <= 12; $mes++) {
                    Configuracao::set("meta_margem_{$ano}_{$mes}", $request->get("meta_margem_{$mes}", 0));
                }
            } elseif ($tipo === 'dias_atraso') {
                for ($mes = 1; $mes <= 12; $mes++) {
                    Configuracao::set("meta_dias_atraso_{$ano}_{$mes}", $request->get("meta_dias_atraso_{$mes}", 0));
                }
            } elseif ($tipo === 'taxa_cobranca') {
                for ($mes = 1; $mes <= 12; $mes++) {
                    Configuracao::set("meta_taxa_cobranca_{$ano}_{$mes}", $request->get("meta_taxa_cobranca_{$mes}", 0));
                }
            } elseif ($tipo === 'anuais') {
                // Salvar metas anuais
                Configuracao::set('meta_avaliacoes_google', $request->get('meta_avaliacoes', 250));
                Configuracao::set('meta_contratos', $request->get('meta_contratos', 400000));
                Configuracao::set('meta_inadimplencia', $request->get('meta_inadimplencia', 1000));
                Configuracao::set('meta_clientes', $request->get('meta_clientes', 80));
            } elseif ($tipo === 'atuais') {
                // Salvar valores atuais
                Configuracao::set('atual_avaliacoes', $request->get('atual_avaliacoes', 0));
            }
            
            return response()->json(['success' => true, 'message' => 'Salvo com sucesso!']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }
    
    /**
     * Salvar metas
     */
    public function salvarMetas(Request $request)
    {
        $ano = $request->get('ano', date('Y'));
        
        // Salvar metas PF
        for ($mes = 1; $mes <= 12; $mes++) {
            $valor = $request->get("meta_pf_$mes", 0);
            Configuracao::set("meta_pf_{$ano}_{$mes}", $valor);
        }
        
        // Salvar metas PJ
        for ($mes = 1; $mes <= 12; $mes++) {
            $valor = $request->get("meta_pj_$mes", 0);
            Configuracao::set("meta_pj_{$ano}_{$mes}", $valor);
        }
        
        // Salvar metas de despesas
        for ($mes = 1; $mes <= 12; $mes++) {
            $valor = $request->get("meta_despesas_$mes", 0);
            Configuracao::set("meta_despesas_{$ano}_{$mes}", $valor);
        }
        
        // Salvar outras metas
        Configuracao::set('meta_avaliacoes_google', $request->get('meta_avaliacoes', 250));
        Configuracao::set('meta_contratos', $request->get('meta_contratos', 400000));
        Configuracao::set('meta_inadimplencia', $request->get('meta_inadimplencia', 1000));
        Configuracao::set('meta_clientes', $request->get('meta_clientes', 80));
        
        return redirect()->back()->with('success', 'Metas salvas com sucesso!');
    }
    
    /**
     * Obter metas mensais de um tipo
     */
    private function getMetasMensais($tipo, $ano)
    {
        $metas = [];
        for ($mes = 1; $mes <= 12; $mes++) {
            $metas[$mes] = (float) Configuracao::get("{$tipo}_{$ano}_{$mes}", 0);
        }
        return $metas;
    }
    
    /**
     * Página: Minha Performance
     */
    public function minhaPerformance(Request $request)
    {
        $ano = (int) $request->get('ano', date('Y'));
        return view('dashboard.minha-performance', ['ano' => $ano]);
    }
    
    /**
     * Página: Equipe
     */
    public function equipe(Request $request)
    {
        $ano = (int) $request->get('ano', date('Y'));
        $advogados = Advogado::all();
        return view('dashboard.equipe', ['ano' => $ano, 'advogados' => $advogados]);
    }
    
    /**
     * Página: Financeiro
     */
    public function financeiro(Request $request)
    {
        $ano = (int) $request->get('ano', date('Y'));
        return view('dashboard.financeiro', ['ano' => $ano]);
    }
    
    /**
     * Página: Processos
     */
    public function processos(Request $request)
    {
        $ano = (int) $request->get('ano', date('Y'));
        return view('dashboard.processos', ['ano' => $ano]);
    }
}

