(function () {
  'use strict';

  // Visão Gerencial já renderiza os gráficos via JS inline no Blade.
  // Este arquivo não pode renderizar/destroir gráficos nessa rota, senão o canvas “pisca e some”.
  // (Também evita o erro "Recursion detected: _scriptable" quando há dupla inicialização.)
  try {
    const isVG = typeof window !== 'undefined'
      && window.location
      && /\/visao-gerencial/.test(window.location.pathname || '');
    if (isVG && typeof window.makeBarChart === 'function' && typeof window.renderCharts === 'function') {
      return;
    }
  } catch (_) {
    // no-op
  }

  const fmtCurrency = (v) => {
    const n = Number(v || 0);
    return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const fmtPct = (v) => {
    const n = Number(v || 0);
    return n.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%';
  };

  const pct = (val, meta) => {
    const v = Number(val || 0);
    const m = Number(meta || 0);
    if (!m) return 0;
    return (v / m) * 100;
  };

  const arrow = (n) => (Number(n) >= 0 ? '↑' : '↓');

  const progressColor = (metricId, percent) => {
    const p = Number(percent || 0);
    if (metricId === 'despesas') {
      if (p > 100) return 'bg-red-500';
      if (p >= 80) return 'bg-amber-500';
      return 'bg-emerald-500';
    }
    if (p >= 80) return 'bg-emerald-500';
    if (p >= 50) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const trendClass = (metricId, trend) => {
    const t = Number(trend || 0);
    const increaseIsBad = ['despesas', 'atraso', 'dias'];
    if (increaseIsBad.includes(metricId)) {
      return t > 0 ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400';
    }
    return t >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400';
  };
  const byId = (id) => document.getElementById(id);
  const byAnyId = (ids) => (ids || []).map((id) => byId(id)).find(Boolean) || null;

  const DEBUG_ENABLED =
    (/[?&]chartsDebug=1/.test(window.location.search)) ||
    (window.localStorage && window.localStorage.getItem('chartsDebug') === '1');

  const __DBG = {
    startedAt: new Date().toISOString(),
    lastBootstrapAt: null,
    lastApplyAt: null,
    attempts: 0,
    initDone: false,
    logs: [],
    errors: [],
  };

  const dbgPush = (level, msg, extra) => {
    const entry = { t: new Date().toISOString(), level, msg, extra: extra || null };
    __DBG.logs.push(entry);
    if (__DBG.logs.length > 200) __DBG.logs.shift();

    if (DEBUG_ENABLED) {
      const fn = level === 'error' ? console.error : (level === 'warn' ? console.warn : console.log);
      fn('[charts]', msg, extra || '');
    }
  };

  const dbgError = (err, where) => {
    const e = err instanceof Error ? err : new Error(String(err));
    __DBG.errors.push({ t: new Date().toISOString(), where: where || null, message: e.message, stack: e.stack || null });
    if (__DBG.errors.length > 100) __DBG.errors.shift();
    dbgPush('error', where ? `${where}: ${e.message}` : e.message);
  };
  const charts = {};

  const destroyAnyChartOnCanvas = (canvasOrId) => {
    try {
      if (typeof Chart === 'undefined' || !Chart.getChart) return;
      const canvas = typeof canvasOrId === 'string' ? byId(canvasOrId) : canvasOrId;
      if (!canvas) return;
      const existing = Chart.getChart(canvas) || (canvas.id ? Chart.getChart(canvas.id) : null);
      if (existing && typeof existing.destroy === 'function') existing.destroy();
    } catch (_) {}
  };

  const buildDiagnosticPayload = () => {
    const data = window.__DASHBOARD_EXEC_DATA__ || null;
    const ids = [
      'chart-receita-pf','chart-receita-pj','chart-rentabilidade',
      'chart-despesas','chart-despesas-rubrica','chart-aging','chart-aging-contas'
    ];
    const canvases = ids.map((id) => {
      const el = byId(id);
      if (!el) return null;
      return { id, w: el.width || null, h: el.height || null, clientW: el.clientWidth || null, clientH: el.clientHeight || null };
    }).filter(Boolean);

    const chartInstances = canvases.map((c) => {
      try {
        const el = byId(c.id);
        const inst = (typeof Chart !== 'undefined' && Chart.getChart) ? (Chart.getChart(el) || Chart.getChart(c.id)) : null;
        return { id: c.id, exists: !!inst };
      } catch (e) {
        return { id: c.id, exists: false, err: String(e) };
      }
    });

    return {
      debugEnabled: DEBUG_ENABLED,
      startedAt: __DBG.startedAt,
      lastBootstrapAt: __DBG.lastBootstrapAt,
      lastApplyAt: __DBG.lastApplyAt,
      attempts: __DBG.attempts,
      chartJsPresent: (typeof Chart !== 'undefined'),
      dataPresent: !!data,
      dataKeys: data ? Object.keys(data) : [],
      canvases,
      chartInstances,
      lastLogs: __DBG.logs.slice(-25),
      lastErrors: __DBG.errors.slice(-10),
    };
  };

  const injectDebugPanelOnce = () => {
    if (!DEBUG_ENABLED) return;
    if (byId('charts-debug-panel')) return;

    const style = document.createElement('style');
    style.id = 'charts-debug-style';
    style.textContent = `
      #charts-debug-panel{position:fixed;right:12px;bottom:12px;z-index:99999;width:min(420px,calc(100vw - 24px));
        font:12px/1.35 system-ui,-apple-system,Segoe UI,Roboto,Arial;background:rgba(15,23,42,.95);color:#e2e8f0;
        border:1px solid rgba(148,163,184,.25);border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.25)}
      #charts-debug-panel header{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid rgba(148,163,184,.18)}
      #charts-debug-panel header .title{font-weight:700}
      #charts-debug-panel header .btns{display:flex;gap:8px}
      #charts-debug-panel button{border:1px solid rgba(148,163,184,.25);background:rgba(30,41,59,.9);color:#e2e8f0;padding:6px 8px;border-radius:8px;cursor:pointer}
      #charts-debug-panel button:hover{background:rgba(51,65,85,.95)}
      #charts-debug-panel .body{padding:10px 12px;max-height:52vh;overflow:auto}
      #charts-debug-panel .k{color:#94a3b8}
      #charts-debug-panel .ok{color:#34d399}
      #charts-debug-panel .bad{color:#fb7185}
      #charts-debug-panel .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace}
      #charts-debug-panel .hr{margin:10px 0;border-top:1px solid rgba(148,163,184,.18)}
      #charts-debug-panel .small{font-size:11px;color:#cbd5e1}
    `;
    document.head.appendChild(style);

    const panel = document.createElement('div');
    panel.id = 'charts-debug-panel';
    panel.innerHTML = `
      <header>
        <div class="title">Charts Debug</div>
        <div class="btns">
          <button type="button" id="charts-debug-force">Forçar render</button>
          <button type="button" id="charts-debug-copy">Copiar diagnóstico</button>
        </div>
      </header>
      <div class="body" id="charts-debug-body"></div>
    `;
    document.body.appendChild(panel);

    const btnForce = byId('charts-debug-force');
    const btnCopy = byId('charts-debug-copy');

    btnForce && btnForce.addEventListener('click', () => {
      try {
        if (window.__DASHBOARD_CHARTS_FORCE_RENDER__) window.__DASHBOARD_CHARTS_FORCE_RENDER__();
        else if (window.__DASHBOARD_CHARTS_BOOTSTRAP__) window.__DASHBOARD_CHARTS_BOOTSTRAP__({ force: true, source: 'debug-panel' });
      } catch (e) {
        dbgError(e, 'debug.force');
      }
    });

    btnCopy && btnCopy.addEventListener('click', async () => {
      try {
        const payload = buildDiagnosticPayload();
        await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
        dbgPush('info', 'Diagnóstico copiado para a área de transferência.');
      } catch (e) {
        dbgError(e, 'debug.copy');
      }
    });

    window.addEventListener('error', (ev) => {
      try { dbgError(ev.error || ev.message, 'window.error'); renderDebugPanel(); } catch (_) {}
    });
    window.addEventListener('unhandledrejection', (ev) => {
      try { dbgError(ev.reason, 'window.unhandledrejection'); renderDebugPanel(); } catch (_) {}
    });

    renderDebugPanel();
  };

  const renderDebugPanel = () => {
    if (!DEBUG_ENABLED) return;
    const body = byId('charts-debug-body');
    if (!body) return;
    const p = buildDiagnosticPayload();
    const ok = (v) => `<span class="${v ? 'ok' : 'bad'}">${v ? 'OK' : 'NÃO'}</span>`;
    body.innerHTML = `
      <div class="small"><span class="k">Chart.js:</span> ${ok(p.chartJsPresent)} &nbsp; <span class="k">Data:</span> ${ok(p.dataPresent)} &nbsp; <span class="k">tentativas:</span> <span class="mono">${p.attempts}</span></div>
      <div class="small"><span class="k">bootstrap:</span> <span class="mono">${p.lastBootstrapAt || '-'}</span> &nbsp; <span class="k">apply:</span> <span class="mono">${p.lastApplyAt || '-'}</span></div>
      <div class="hr"></div>
      <div class="small"><span class="k">Canvases:</span></div>
      <div class="mono small">${(p.chartInstances || []).map(ci => `${ci.exists ? '✓' : '×'} ${ci.id}`).join('<br>')}</div>
      <div class="hr"></div>
      <div class="small"><span class="k">Últimos erros:</span></div>
      <div class="mono small">${(p.lastErrors || []).length ? p.lastErrors.map(e => `${e.t} ${e.where || ''} ${e.message}`).join('<br>') : '(nenhum)'}</div>
    `;
  };

  const destroyAllCharts = () => {
    try {
      Object.keys(charts).forEach((k) => {
        if (charts[k] && typeof charts[k].destroy === 'function') {
          charts[k].destroy();
        }
        charts[k] = null;
      });
      // Também garante limpeza por canvas (caso chart não esteja no map)
      ['chart-receita-pf','chart-receita-pj','chart-rentabilidade','chart-despesas','chart-despesas-rubrica','chart-aging','chart-aging-contas']
        .forEach((id) => destroyAnyChartOnCanvas(id));
    } catch (e) {
      dbgError(e, 'destroyAllCharts');
    }
  };


  const buildReceitaLineChart = (ctxId, title, labels, meta, realizado) => {
    const ctx = byId(ctxId);
    if (!ctx) return null;
    return new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Meta',
            data: meta,
            borderColor: '#3B82F6',
            backgroundColor: 'rgba(59, 130, 246, 0.15)',
            borderWidth: 3,
            pointRadius: 2,
            tension: 0.3,
          },
          {
            label: 'Realizado',
            data: realizado,
            borderColor: '#10B981',
            backgroundColor: 'rgba(16, 185, 129, 0.12)',
            borderWidth: 3,
            pointRadius: 2,
            tension: 0.3,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: { display: false, text: title },
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${fmtCurrency(ctx.raw)}`,
            },
          },
        },
        scales: {
          y: {
            ticks: { callback: (v) => fmtCurrency(v) },
            grid: { color: 'rgba(156, 163, 175, 0.2)' },
          },
          x: { grid: { display: false } },
        },
      },
    });
  };

  const buildReceitaPFChart = (data) => {
    const d = data.receitaPF12Meses || {};
    const labels = (d.meses && d.meses.length ? d.meses : ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']);
    const meta = (d.meta || []).map((n) => Number(n));
    const real = (d.realizado || []).map((n) => Number(n));
    destroyAnyChartOnCanvas('chart-receita-pf');
    if (charts.receitaPF) charts.receitaPF.destroy();
    charts.receitaPF = buildReceitaLineChart('chart-receita-pf', 'Receita PF', labels, meta, real);
  };

  const buildReceitaPJChart = (data) => {
    const d = data.receitaPJ12Meses || {};
    const labels = (d.meses && d.meses.length ? d.meses : ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']);
    const meta = (d.meta || []).map((n) => Number(n));
    const real = (d.realizado || []).map((n) => Number(n));
    destroyAnyChartOnCanvas('chart-receita-pj');
    if (charts.receitaPJ) charts.receitaPJ.destroy();
    charts.receitaPJ = buildReceitaLineChart('chart-receita-pj', 'Receita PJ', labels, meta, real);
  };

  const buildLucratividadeChart = (data) => {
    const ctx = byId('chart-rentabilidade');
    if (!ctx) return;
    const d = data.lucratividade12Meses || {};
    const labels = d.meses || [];
    const receita = (d.receita || []).map((n) => Number(n));
    const despesas = (d.despesas || []).map((n) => Number(n));
    const lucro = (d.lucratividade || []).map((n) => Number(n));
    const colors = lucro.map((v) => (v > 0 ? '#10B981' : v < 0 ? '#EF4444' : '#9CA3AF'));
    if (ctx) destroyAnyChartOnCanvas(ctx);
    if (charts.lucratividade) charts.lucratividade.destroy();
    charts.lucratividade = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Receita',
            data: receita,
            backgroundColor: 'rgba(59, 130, 246, 0.5)',
            borderColor: '#3B82F6',
            borderWidth: 1,
          },
          {
            label: 'Despesas',
            data: despesas,
            backgroundColor: 'rgba(239, 68, 68, 0.5)',
            borderColor: '#EF4444',
            borderWidth: 1,
          },
          {
            label: 'Lucro',
            data: lucro,
            backgroundColor: colors,
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${fmtCurrency(ctx.raw)}`,
            },
          },
        },
        scales: {
          y: {
            ticks: { callback: (v) => fmtCurrency(v) },
            grid: { color: 'rgba(156, 163, 175, 0.2)' },
          },
          x: { grid: { display: false } },
        },
      },
    });
  };

  const buildDespesasChart = (data) => {
    const ctx = byAnyId(['chart-despesas', 'chart-despesas-rubrica']);
    if (!ctx) return;
    const d = data.despesasRubrica || [];
    const labels = d.map((r) => r.rubrica);
    const values = d.map((r) => Number(r.valor));
    if (ctx) destroyAnyChartOnCanvas(ctx);
    if (charts.despesas) charts.despesas.destroy();
    charts.despesas = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [
          {
            data: values,
            backgroundColor: [
              '#3B82F6',
              '#10B981',
              '#F59E0B',
              '#EF4444',
              '#8B5CF6',
              '#EC4899',
              '#14B8A6',
              '#F97316',
            ],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.label}: ${fmtCurrency(ctx.raw)}`,
            },
          },
        },
      },
    });
  };

  const buildAgingChart = (data) => {
    const ctx = byAnyId(['chart-aging', 'chart-aging-contas']);
    if (!ctx) return;
    const d = data.agingContas || {};
    const labels = d.faixas || [];
    const values = d.valores || [];
    if (ctx) destroyAnyChartOnCanvas(ctx);
    if (charts.aging) charts.aging.destroy();
    charts.aging = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Valor em Atraso',
            data: values,
            backgroundColor: [
              'rgba(34, 197, 94, 0.7)',
              'rgba(245, 158, 11, 0.7)',
              'rgba(239, 68, 68, 0.7)',
              'rgba(127, 29, 29, 0.7)',
            ],
            borderColor: ['#22C55E', '#F59E0B', '#EF4444', '#7F1D1D'],
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => `${fmtCurrency(ctx.raw)}`,
            },
          },
        },
        scales: {
          y: {
            ticks: { callback: (v) => fmtCurrency(v) },
            grid: { color: 'rgba(156, 163, 175, 0.2)' },
          },
          x: { grid: { display: false } },
        },
      },
    });
  };

  const renderKpis = (data) => {
    const s = data.resumoExecutivo || {};
    const renderKpi = (id, value, meta, trend, metricId) => {
      const el = byId(id);
      if (!el) return;
      const p = pct(value, meta);
      const pc = progressColor(metricId, p);
      const tc = trendClass(metricId, trend);
      el.innerHTML = `
        <div class="space-y-2">
          <div class="text-2xl font-bold text-gray-900 dark:text-gray-200">${fmtCurrency(value)}</div>
          <div class="text-xs text-gray-500">Meta: ${fmtCurrency(meta)} (${fmtPct(p)})</div>
          <div class="flex items-center gap-1">
            <span class="inline-block px-2 py-1 rounded text-xs font-semibold ${pc}">
              ${p >= 80 ? 'OK' : p >= 50 ? 'ATENÇÃO' : 'CRÍTICO'}
            </span>
            <span class="${tc}">
              ${arrow(trend)} ${fmtPct(trend)} vs mês anterior
            </span>
          </div>
        </div>
      `;
    };
    renderKpi('kpi-receita', s.receitaTotal, s.receitaMeta, s.receitaTrend, 'receita');
    renderKpi('kpi-despesas', s.despesasTotal, s.despesasMeta, s.despesasTrend, 'despesas');
    renderKpi('kpi-resultado', s.resultadoLiquido, s.resultadoMeta, s.resultadoTrend, 'resultado');
    renderKpi('kpi-margem', s.margemLiquida, 100, s.margemTrend, 'margem');
    renderKpi('kpi-atraso', s.diasAtraso, s.diasAtrasoMeta, s.diasAtrasoTrend, 'dias');
  };

  const renderDespesasTable = (data) => {
    const el = byId('tbl-despesas-rubrica');
    if (!el) return;
    const d = data.despesasRubrica || [];
    el.innerHTML = d.map((r) => {
      const valor = Number(r.valor || 0);
      const meta = Number(r.meta || 0);
      const p = meta > 0 ? (valor / meta) * 100 : 0;
      const trend = Number(r.trend || 0);
      const tClass = trendClass('despesas', trend);
      return `
        <tr>
          <td class="px-3 py-2 text-sm text-gray-800 dark:text-gray-200">${r.rubrica ?? ''}</td>
          <td class="px-3 py-2 text-sm text-right font-semibold text-gray-900 dark:text-gray-200">${fmtCurrency(valor)}</td>
          <td class="px-3 py-2 text-sm text-right text-gray-700 dark:text-gray-300">${fmtCurrency(meta)}</td>
          <td class="px-3 py-2 text-sm text-right text-gray-700 dark:text-gray-300">${fmtPct(p)}</td>
          <td class="px-3 py-2 text-sm text-right ${tClass}">${arrow(trend)} ${fmtPct(trend)}</td>
        </tr>
      `;
    }).join('');
  };

  const renderAtrasosTable = (data) => {
    const el = byId('tbl-atrasos');
    if (!el) return;
    const d = data.contasAtrasoLista || [];
    el.innerHTML = d.slice(0, 5).map((c) => `
      <tr>
        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-300">${c.numero}</td>
        <td class="px-4 py-2 text-sm text-gray-700 dark:text-gray-300">${c.cliente}</td>
        <td class="px-4 py-2 text-sm text-right font-semibold text-red-600">${fmtCurrency(c.valor)}</td>
        <td class="px-4 py-2 text-sm text-right text-red-600">${c.diasAtraso} dias</td>
      </tr>
    `).join('');
  };

  const renderComparativo = (data) => {
    const el = byId('tbl-comparativo');
    if (!el) return;
    const rows = Array.isArray(data.comparativoMensal) ? data.comparativoMensal : [];

    const isPercentMetric = (name) => {
      const n = String(name || '').toLowerCase();
      return n.includes('margem') || n.includes('taxa');
    };

    const fmtValue = (name, v) => {
      const num = Number(v || 0);
      return isPercentMetric(name) ? fmtPct(num) : fmtCurrency(num);
    };

    const iconFor = (name) => {
      const n = String(name || '').toLowerCase();
      if (n.includes('receita')) return '💰';
      if (n.includes('despesa')) return '📉';
      if (n.includes('resultado')) return '📈';
      if (n.includes('margem')) return '📊';
      if (n.includes('atraso')) return '⏰';
      if (n.includes('cobran')) return '✅';
      return '•';
    };

    el.innerHTML = rows.map((r) => {
      const name = r.metrica ?? '';
      const trend = Number(r.trend || 0);
      const tClass = trendClass(name.toLowerCase().includes('despesa') ? 'despesas' : '', trend);
      return `
        <tr>
          <td class="px-3 py-2 text-sm font-semibold text-gray-800 dark:text-gray-200"><span class="mr-2" aria-hidden="true">${iconFor(name)}</span>${name}</td>
          <td class="px-3 py-2 text-sm text-right text-gray-700 dark:text-gray-300">${fmtValue(name, r.mes1)}</td>
          <td class="px-3 py-2 text-sm text-right text-gray-700 dark:text-gray-300">${fmtValue(name, r.mes2)}</td>
          <td class="px-3 py-2 text-sm text-right font-semibold text-gray-900 dark:text-gray-200">${fmtValue(name, r.mes3)}</td>
          <td class="px-3 py-2 text-sm text-right ${tClass}">${arrow(trend)} ${fmtPct(trend)}</td>
        </tr>
      `;
    }).join('');
  };

    const applyData = (data) => {
    __DBG.lastApplyAt = new Date().toISOString();
    try {
      console.log('[Dashboard] applyData chamado');
      renderKpis(data);
      renderDespesasTable(data);
      renderAtrasosTable(data);
      renderComparativo(data);
      buildReceitaPFChart(data);
      buildReceitaPJChart(data);
      buildLucratividadeChart(data);
      buildDespesasChart(data);
      buildAgingChart(data);
      console.log('[Dashboard] Todos os gráficos criados');
    } catch (e) {
      dbgError(e, 'applyData');
    } finally {
      renderDebugPanel();
    }
  };

  const resolveApiUrl = () => window.__DASHBOARD_API_URL__ || '/api/visao-gerencial';
  const resolveExportUrl = () => window.__DASHBOARD_EXPORT_URL__ || '/visao-gerencial/export';

  const setupFilters = () => {
    const selAno = byId('filter-ano');
    const selMes = byId('filter-mes');
    const doUpdate = async () => {
      if (!selAno || !selMes) return;
      const ano = Number(selAno.value);
      const mes = Number(selMes.value);
      const url = new URL(resolveApiUrl(), window.location.origin);
      url.searchParams.set('ano', String(ano));
      url.searchParams.set('mes', String(mes));
      const res = await fetch(url.toString());
      if (!res.ok) {
        dbgPush('error', 'Erro ao buscar dados', { status: res.status });
        return;
      }
      const data = await res.json();
      window.__DASHBOARD_EXEC_DATA__ = data;
      applyData(data);
      const exp = byId('export-csv');
      if (exp) {
        const u = new URL(resolveExportUrl(), window.location.origin);
        u.searchParams.set('ano', String(ano));
        u.searchParams.set('mes', String(mes));
        exp.href = u.toString();
      }
    };
    if (selAno) selAno.addEventListener('change', doUpdate);
    if (selMes) selMes.addEventListener('change', doUpdate);
  };

  const setupExportMenu = () => {
    const btn = byId('btn-export');
    const menu = byId('export-menu');
    const pdf = byId('export-pdf');
    const csv = byId('export-csv');
    const selAno = byId('filter-ano');
    const selMes = byId('filter-mes');
    const syncCsvLink = () => {
      if (!csv || !selAno || !selMes) return;
      const u = new URL(resolveExportUrl(), window.location.origin);
      u.searchParams.set('ano', String(selAno.value));
      u.searchParams.set('mes', String(selMes.value));
      csv.href = u.toString();
    };
    syncCsvLink();
    if (btn && menu) {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.classList.toggle('hidden');
      });
      document.addEventListener('click', () => menu.classList.add('hidden'));
    }
    if (pdf) {
      pdf.addEventListener('click', () => {
        if (menu) menu.classList.add('hidden');
        window.print();
      });
    }
  };

    // ===== INICIALIZAÇÃO SIMPLIFICADA E ROBUSTA =====
  const bootstrap = (opts) => {
    const options = opts || {};
    const force = !!options.force;
    const source = options.source || 'auto';

    __DBG.lastBootstrapAt = new Date().toISOString();
    injectDebugPanelOnce();

    console.log('[Dashboard] Bootstrap iniciado');
    const data = window.__DASHBOARD_EXEC_DATA__;

    if (!data) {
      const msg = 'window.__DASHBOARD_EXEC_DATA__ não existe';
      console.error('[Dashboard] ❌ ' + msg);
      dbgPush('error', msg, { source });
      renderDebugPanel();
      return false;
    }

    console.log('[Dashboard] ✅ Dados disponíveis');

    try {
      if (!__DBG.initDone) {
        setupFilters();
        setupExportMenu();
        __DBG.initDone = true;
      }

      if (force) {
        destroyAllCharts();
      }

      applyData(data);
      console.log('[Dashboard] ✅ Bootstrap completo - todos os gráficos criados');
      dbgPush('info', 'bootstrap ok', { source, force });
      return true;
    } catch (e) {
      console.error('[Dashboard] ❌ Erro durante bootstrap:', e.message);
      dbgError(e, 'bootstrap');
      return false;
    } finally {
      renderDebugPanel();
    }
  };

  // Hooks globais (úteis para depuração)
  window.__DASHBOARD_CHARTS_BOOTSTRAP__ = bootstrap;
  window.__DASHBOARD_CHARTS_FORCE_RENDER__ = () => bootstrap({ force: true, source: 'manual' });
  window.__DASHBOARD_CHARTS_DIAGNOSTIC__ = buildDiagnosticPayload;

  // Inicialização com retry robusto
  const initWithRetry = (attempt = 1) => {
    const MAX = 20;
    const DELAY = 100;
    
    __DBG.attempts = attempt;
    console.log(`[Dashboard] Tentativa ${attempt}/${MAX}`);
    if (DEBUG_ENABLED) { try { injectDebugPanelOnce(); renderDebugPanel(); } catch (_) {} }
    
    // Verificar Chart.js
    if (typeof Chart !== 'function') {
      console.log('[Dashboard] ❌ Chart.js não carregado ainda');
      if (attempt < MAX) {
        setTimeout(() => initWithRetry(attempt + 1), DELAY);
      } else {
        console.error('[Dashboard] ❌ Chart.js nunca foi carregado');
      }
      return;
    }
    
    console.log('[Dashboard] ✅ Chart.js carregado');
    
    // Verificar dados
    if (!window.__DASHBOARD_EXEC_DATA__) {
      console.log('[Dashboard] ❌ Dados não disponíveis ainda');
      if (attempt < MAX) {
        setTimeout(() => initWithRetry(attempt + 1), DELAY);
      } else {
        console.error('[Dashboard] ❌ Dados nunca foram injetados');
      }
      return;
    }
    
    console.log('[Dashboard] ✅ Dados disponíveis');
    
    // Tudo pronto, executar bootstrap
    bootstrap({ source: 'retry' });
  };

  // Garantir que DOM está pronto antes de iniciar
  if (document.readyState === 'loading') {
    console.log('[Dashboard] DOM ainda carregando, aguardando DOMContentLoaded');
    document.addEventListener('DOMContentLoaded', () => {
      console.log('[Dashboard] DOMContentLoaded disparado');
      setTimeout(initWithRetry, 100);
    });
  } else {
    console.log('[Dashboard] DOM já pronto, iniciando com delay');
    setTimeout(initWithRetry, 100);
  }

  if (DEBUG_ENABLED) {
    setInterval(() => { try { renderDebugPanel(); } catch (_) {} }, 1000);
  }
})();
