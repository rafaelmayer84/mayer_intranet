{{--
    _kpi-card.blade.php v2
    Componente universal de KPI Card — RESULTADOS!

    Variáveis aceitas (todas opcionais exceto title e value):
      $id        string   Identificador único do card (ex: 'receita')
      $title     string   Título do KPI
      $value     string   Valor formatado (ex: 'R$ 10.199,08')
      $meta      mixed    Meta formatada ou null (exibe "Meta: —" quando null/vazio)
      $percent   float    % de atingimento (0-100+). Ignorado se meta ausente.
      $trend     float    Variação % vs período anterior (positivo=bom para receita, negativo=bom para despesa)
      $icon      string   Emoji ou ícone
      $accent    string   Cor do card: green|blue|orange|purple|red|yellow
      $sparkline array    Array de 12 valores numéricos para mini gráfico (opcional)
      $status    string   ok|atencao|critico|sem_meta (auto-calculado se omitido)
      $invertTrend bool   Se true, trend negativo é "bom" (ex: despesas caindo). Default false.

    Retrocompatível: chamadas antigas sem sparkline/status continuam funcionando.
--}}

@php
    $id = $id ?? 'kpi-' . Str::random(6);
    $title = $title ?? 'KPI';
    $value = $value ?? '—';
    $icon = $icon ?? '📊';
    $accent = $accent ?? 'blue';
    $trend = isset($trend) ? (float) $trend : null;
    $invertTrend = $invertTrend ?? false;
    $sparkline = $sparkline ?? null;

    // Meta: null, '', '0', 0 => sem meta
    $hasMeta = isset($meta) && $meta !== null && $meta !== '' && $meta !== 'R$ 0,00' && $meta !== '0' && $meta !== 0;
    $percent = $hasMeta ? (float) ($percent ?? 0) : 0;

    // Status automático
    if (isset($status)) {
        $statusCalc = $status;
    } elseif (!$hasMeta) {
        $statusCalc = 'sem_meta';
    } elseif ($percent >= 90) {
        $statusCalc = 'ok';
    } elseif ($percent >= 70) {
        $statusCalc = 'atencao';
    } else {
        $statusCalc = 'critico';
    }

    // Cores do accent
    $accentColors = [
        'green'  => ['border' => 'border-emerald-500', 'bg' => 'bg-emerald-50 dark:bg-emerald-900/20', 'text' => 'text-emerald-600 dark:text-emerald-400'],
        'blue'   => ['border' => 'border-blue-500',    'bg' => 'bg-blue-50 dark:bg-blue-900/20',       'text' => 'text-blue-600 dark:text-blue-400'],
        'orange' => ['border' => 'border-orange-500',   'bg' => 'bg-orange-50 dark:bg-orange-900/20',   'text' => 'text-orange-600 dark:text-orange-400'],
        'purple' => ['border' => 'border-purple-500',   'bg' => 'bg-purple-50 dark:bg-purple-900/20',   'text' => 'text-purple-600 dark:text-purple-400'],
        'red'    => ['border' => 'border-red-500',      'bg' => 'bg-red-50 dark:bg-red-900/20',         'text' => 'text-red-600 dark:text-red-400'],
        'yellow' => ['border' => 'border-yellow-500',   'bg' => 'bg-yellow-50 dark:bg-yellow-900/20',   'text' => 'text-yellow-600 dark:text-yellow-400'],
    ];
    $ac = $accentColors[$accent] ?? $accentColors['blue'];

    // Badge de status
    $statusBadge = match($statusCalc) {
        'ok'       => '<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">OK</span>',
        'atencao'  => '<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300">Atenção</span>',
        'critico'  => '<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300">Crítico</span>',
        'sem_meta' => '<span class="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400">—</span>',
        default    => '',
    };

    // Trend arrow e cor
    $trendHtml = '';
    if ($trend !== null && $hasMeta) {
        $isGood = $invertTrend ? ($trend <= 0) : ($trend >= 0);
        $arrow = $trend >= 0 ? '↑' : '↓';
        $trendColor = $isGood ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400';
        $trendHtml = '<span class="text-xs font-medium ' . $trendColor . '">' . $arrow . ' ' . number_format(abs($trend), 1, ',', '.') . '%</span>';
    }
@endphp

<div id="card-{{ $id }}" class="rounded-2xl border-t-4 {{ $ac['border'] }} bg-gradient-to-b from-white to-gray-50 dark:from-gray-800 dark:to-gray-900 p-4 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden">
    {{-- Header: título + badge status --}}
    <div class="flex items-start justify-between gap-2">
        <div class="min-w-0 flex-1">
            <div class="flex items-center gap-1.5">
                <p class="text-xs font-medium text-gray-500 dark:text-gray-400 truncate">{{ $title }}</p>
                {!! $statusBadge !!}
            </div>

            {{-- Valor principal --}}
            <p class="mt-1.5 text-2xl font-bold text-gray-900 dark:text-white leading-tight">{{ $value }}</p>

            {{-- Meta + Trend --}}
            <div class="mt-1 flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                @if($hasMeta)
                    <span>Meta: {{ $meta }}</span>
                    @if($percent > 0)
                        <span class="font-medium {{ $percent >= 100 ? 'text-emerald-600 dark:text-emerald-400' : ($percent >= 70 ? 'text-yellow-600 dark:text-yellow-400' : 'text-red-600 dark:text-red-400') }}">
                            {{ number_format($percent, 0) }}%
                        </span>
                    @endif
                @else
                    <span>Meta: —</span>
                @endif
                {!! $trendHtml !!}
            </div>
        </div>

        {{-- Ícone --}}
        <div class="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl {{ $ac['bg'] }}">
            <span class="text-lg">{{ $icon }}</span>
        </div>
    </div>

    {{-- Barra de progresso (só se tiver meta) --}}
    @if($hasMeta && $percent > 0)
        <div class="mt-3 h-1.5 w-full rounded-full bg-gray-200 dark:bg-gray-700 overflow-hidden">
            <div class="h-full rounded-full transition-all duration-700 {{ $percent >= 100 ? 'bg-emerald-500' : ($percent >= 70 ? 'bg-yellow-500' : 'bg-red-500') }}"
                 style="width: {{ min($percent, 100) }}%"></div>
        </div>
    @endif

    {{-- Sparkline (mini gráfico SVG inline — zero dependência JS) --}}
    @if(is_array($sparkline) && count($sparkline) >= 2)
        @php
            $spk = array_values(array_slice($sparkline, -12)); // últimos 12 pontos
            $spkCount = count($spk);
            $spkMin = min($spk);
            $spkMax = max($spk);
            $spkRange = max($spkMax - $spkMin, 1); // evitar divisão por zero
            $svgW = 120;
            $svgH = 28;
            $padding = 2;

            $points = [];
            for ($i = 0; $i < $spkCount; $i++) {
                $x = $padding + ($i / max($spkCount - 1, 1)) * ($svgW - 2 * $padding);
                $y = $padding + (1 - ($spk[$i] - $spkMin) / $spkRange) * ($svgH - 2 * $padding);
                $points[] = round($x, 1) . ',' . round($y, 1);
            }
            $polyline = implode(' ', $points);

            // Área preenchida (fechar o path embaixo)
            $areaPath = 'M' . $points[0];
            for ($i = 1; $i < $spkCount; $i++) {
                $areaPath .= ' L' . $points[$i];
            }
            $lastX = $padding + (($spkCount - 1) / max($spkCount - 1, 1)) * ($svgW - 2 * $padding);
            $firstX = $padding;
            $areaPath .= ' L' . round($lastX, 1) . ',' . $svgH . ' L' . round($firstX, 1) . ',' . $svgH . ' Z';

            // Cor da sparkline segue o accent
            $spkStroke = match($accent) {
                'green' => '#10b981', 'blue' => '#3b82f6', 'orange' => '#f97316',
                'purple' => '#8b5cf6', 'red' => '#ef4444', 'yellow' => '#eab308',
                default => '#6b7280',
            };
        @endphp
        <div class="mt-2">
            <svg width="{{ $svgW }}" height="{{ $svgH }}" viewBox="0 0 {{ $svgW }} {{ $svgH }}" class="w-full" preserveAspectRatio="none">
                <path d="{{ $areaPath }}" fill="{{ $spkStroke }}" fill-opacity="0.1" />
                <polyline points="{{ $polyline }}" fill="none" stroke="{{ $spkStroke }}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
        </div>
    @endif
</div>
