<?php
/**
 * PATCH para routes/api.php
 * TRECHO A ADICIONAR via Python patch.
 * NÃO é arquivo standalone.
 */

// ─── NEXO QA: Webhook de Respostas de Pesquisa ───
Route::post('/webhooks/sendpulse/nexo-qa', [\App\Http\Controllers\Api\NexoQaWebhookController::class, 'handle'])
    ->name('webhooks.sendpulse.nexo-qa');
