<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Crm\PipelineController;
use App\Http\Controllers\Crm\OpportunityController;
use App\Http\Controllers\Crm\ActivityController;
use App\Http\Controllers\Crm\ReportsController;

/*
|--------------------------------------------------------------------------
| CRM Comercial Routes
|--------------------------------------------------------------------------
| Prefix: /crm
| Middleware: auth
*/

Route::prefix('crm')->middleware('auth')->group(function () {

    // Pipeline (Kanban)
    Route::get('/', [PipelineController::class, 'index'])->name('crm.pipeline');

    // Oportunidades
    Route::get('/oportunidades/criar', [OpportunityController::class, 'create'])->name('crm.opportunity.create');
    Route::post('/oportunidades', [OpportunityController::class, 'store'])->name('crm.opportunity.store');
    Route::get('/oportunidades/{id}', [OpportunityController::class, 'show'])->name('crm.opportunity.show');
    Route::put('/oportunidades/{id}', [OpportunityController::class, 'update'])->name('crm.opportunity.update');
    Route::post('/oportunidades/{id}/mover-estagio', [OpportunityController::class, 'moveStage'])->name('crm.opportunity.move-stage');
    Route::post('/oportunidades/{id}/ganho', [OpportunityController::class, 'markWon'])->name('crm.opportunity.won');
    Route::post('/oportunidades/{id}/perda', [OpportunityController::class, 'markLost'])->name('crm.opportunity.lost');

    // Atividades
    Route::post('/atividades', [ActivityController::class, 'store'])->name('crm.activity.store');
    Route::post('/atividades/{id}/concluir', [ActivityController::class, 'complete'])->name('crm.activity.complete');

    // Relatórios
    Route::get('/relatorios', [ReportsController::class, 'index'])->name('crm.reports');

    // APIs internas
    Route::get('/api/pipeline-kpis', [PipelineController::class, 'kpisJson'])->name('crm.api.kpis');
    Route::get('/api/accounts/search', [PipelineController::class, 'searchAccounts'])->name('crm.accounts.search');
});
