<?php

namespace App\Services\Crm;

use App\Models\Crm\Account;
use App\Models\Crm\Identity;
use App\Models\Crm\Event;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CrmIdentityResolver
{
    /**
     * Resolve identidades para um Account existente ou cria um novo.
     *
     * @param string|null $phone   Telefone (qualquer formato)
     * @param string|null $email   Email
     * @param string|null $doc     CPF/CNPJ
     * @param array       $defaults Campos default para Account novo: name, type, owner_user_id, notes
     * @param array       $extras  Identidades extras: ['datajuri' => '123', 'sendpulse' => 'abc', 'espocrm' => '456']
     * @return Account
     */
    public function resolve(
        ?string $phone = null,
        ?string $email = null,
        ?string $doc = null,
        array $defaults = [],
        array $extras = []
    ): Account {
        // Normalizar
        $phoneNorm = Identity::normalizePhone($phone);
        $emailNorm = Identity::normalizeEmail($email);
        $docNorm   = Identity::normalizeDoc($doc);

        // Tentar encontrar account existente por qualquer identidade
        $account = $this->findByIdentity('phone', $phoneNorm)
                ?? $this->findByIdentity('email', $emailNorm)
                ?? $this->findByIdentity('doc', $docNorm);

        // Verificar extras (datajuri, sendpulse, espocrm)
        if (!$account) {
            foreach ($extras as $kind => $value) {
                if (!empty($value) && in_array($kind, ['datajuri', 'sendpulse', 'espocrm'])) {
                    $account = $this->findByIdentity($kind, (string) $value);
                    if ($account) {
                        break;
                    }
                }
            }
        }

        if ($account) {
            // Account encontrado — adicionar identidades faltantes
            $this->ensureIdentity($account, 'phone', $phone, $phoneNorm);
            $this->ensureIdentity($account, 'email', $email, $emailNorm);
            $this->ensureIdentity($account, 'doc', $doc, $docNorm);

            foreach ($extras as $kind => $value) {
                if (!empty($value) && in_array($kind, ['datajuri', 'sendpulse', 'espocrm'])) {
                    $this->ensureIdentity($account, $kind, (string) $value, (string) $value);
                }
            }

            // Atualizar name se estava vazio e agora temos
            if (empty($account->name) && !empty($defaults['name'])) {
                $account->update(['name' => $defaults['name']]);
            }

            return $account;
        }

        // Criar novo account
        return $this->createAccount($phone, $phoneNorm, $email, $emailNorm, $doc, $docNorm, $defaults, $extras);
    }

    /**
     * Busca account por identidade normalizada.
     */
    private function findByIdentity(string $kind, ?string $valueNorm): ?Account
    {
        if (empty($valueNorm)) {
            return null;
        }

        $identity = Identity::where('kind', $kind)
            ->where('value_norm', $valueNorm)
            ->first();

        return $identity ? $identity->account : null;
    }

    /**
     * Garante que uma identidade existe para o account.
     */
    private function ensureIdentity(Account $account, string $kind, ?string $value, ?string $valueNorm): void
    {
        if (empty($valueNorm)) {
            return;
        }

        $exists = Identity::where('kind', $kind)
            ->where('value_norm', $valueNorm)
            ->exists();

        if (!$exists) {
            try {
                Identity::create([
                    'account_id' => $account->id,
                    'kind' => $kind,
                    'value' => $value ?? $valueNorm,
                    'value_norm' => $valueNorm,
                ]);
            } catch (\Illuminate\Database\QueryException $e) {
                // Unique constraint — outro processo criou ao mesmo tempo
                Log::debug('CRM Identity duplicada ignorada', [
                    'kind' => $kind,
                    'value_norm' => $valueNorm,
                ]);
            }
        }
    }

    /**
     * Cria account + identidades em transação.
     */
    private function createAccount(
        ?string $phone, ?string $phoneNorm,
        ?string $email, ?string $emailNorm,
        ?string $doc, ?string $docNorm,
        array $defaults,
        array $extras
    ): Account {
        return DB::transaction(function () use ($phone, $phoneNorm, $email, $emailNorm, $doc, $docNorm, $defaults, $extras) {

            // Inferir tipo PF/PJ pelo doc
            $type = $defaults['type'] ?? 'PF';
            if (!empty($docNorm) && strlen($docNorm) === 14) {
                $type = 'PJ';
            }

            // Inferir name
            $name = $defaults['name'] ?? $email ?? $phone ?? 'Sem nome';

            $account = Account::create([
                'type' => $type,
                'name' => $name,
                'doc_digits' => $docNorm,
                'notes' => $defaults['notes'] ?? null,
                'owner_user_id' => $defaults['owner_user_id'] ?? null,
            ]);

            // Criar identidades
            $identities = [];
            if ($phoneNorm) {
                $identities[] = ['kind' => 'phone', 'value' => $phone ?? $phoneNorm, 'value_norm' => $phoneNorm];
            }
            if ($emailNorm) {
                $identities[] = ['kind' => 'email', 'value' => $email, 'value_norm' => $emailNorm];
            }
            if ($docNorm) {
                $identities[] = ['kind' => 'doc', 'value' => $doc ?? $docNorm, 'value_norm' => $docNorm];
            }
            foreach ($extras as $kind => $value) {
                if (!empty($value) && in_array($kind, ['datajuri', 'sendpulse', 'espocrm'])) {
                    $identities[] = ['kind' => $kind, 'value' => (string) $value, 'value_norm' => (string) $value];
                }
            }

            foreach ($identities as $ident) {
                try {
                    $account->identities()->create($ident);
                } catch (\Illuminate\Database\QueryException $e) {
                    Log::debug('CRM Identity duplicada no create', ['ident' => $ident]);
                }
            }

            // Registrar evento
            Event::log('account_created', null, $account->id, [
                'name' => $account->name,
                'type' => $account->type,
                'identities_count' => count($identities),
            ]);

            Log::info('CRM Account criado', [
                'account_id' => $account->id,
                'name' => $account->name,
                'identities' => count($identities),
            ]);

            return $account;
        });
    }
}
