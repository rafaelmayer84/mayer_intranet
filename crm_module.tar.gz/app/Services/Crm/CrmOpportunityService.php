<?php

namespace App\Services\Crm;

use App\Models\Crm\Account;
use App\Models\Crm\Opportunity;
use App\Models\Crm\Stage;
use App\Models\Crm\Event;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CrmOpportunityService
{
    /**
     * Cria oportunidade ou retorna aberta existente para o account.
     * Evita duplicatas: se já há oportunidade open com mesma area, retorna ela.
     */
    public function createOrGetOpen(Account $account, array $data): Opportunity
    {
        // Verificar se já existe oportunidade open com mesma area
        $existing = $account->opportunities()
            ->where('status', 'open')
            ->when(!empty($data['area']), function ($q) use ($data) {
                $q->where('area', $data['area']);
            })
            ->first();

        if ($existing) {
            Log::info('CRM Oportunidade existente retornada', [
                'opportunity_id' => $existing->id,
                'account_id' => $account->id,
            ]);
            return $existing;
        }

        return $this->create($account, $data);
    }

    /**
     * Cria nova oportunidade.
     */
    public function create(Account $account, array $data): Opportunity
    {
        return DB::transaction(function () use ($account, $data) {
            // Stage inicial: primeiro workable por sort
            $stageId = $data['stage_id']
                ?? Stage::workable()->ordered()->value('id')
                ?? Stage::active()->ordered()->value('id');

            $opportunity = Opportunity::create([
                'account_id' => $account->id,
                'stage_id' => $stageId,
                'title' => $data['title'] ?? $account->name . ' - Nova oportunidade',
                'area' => $data['area'] ?? null,
                'source' => $data['source'] ?? null,
                'value_estimated' => $data['value_estimated'] ?? null,
                'owner_user_id' => $data['owner_user_id'] ?? auth()->id(),
                'next_action_at' => $data['next_action_at'] ?? now()->addBusinessDays(2),
                'status' => 'open',
                'lead_id' => $data['lead_id'] ?? null,
            ]);

            Event::log('opportunity_created', $opportunity->id, $account->id, [
                'title' => $opportunity->title,
                'stage' => Stage::find($stageId)?->name,
                'source' => $opportunity->source,
            ]);

            Log::info('CRM Oportunidade criada', [
                'opportunity_id' => $opportunity->id,
                'account_id' => $account->id,
                'title' => $opportunity->title,
            ]);

            return $opportunity;
        });
    }

    /**
     * Move oportunidade para outro estágio.
     */
    public function moveStage(Opportunity $opportunity, int $stageId): Opportunity
    {
        $oldStage = $opportunity->stage;
        $newStage = Stage::findOrFail($stageId);

        if ($oldStage->id === $newStage->id) {
            return $opportunity;
        }

        // Se stage é won/lost, usar métodos específicos
        if ($newStage->is_won) {
            return $this->markWon($opportunity);
        }
        if ($newStage->is_lost) {
            return $this->markLost($opportunity, 'Movido para ' . $newStage->name);
        }

        $opportunity->update(['stage_id' => $stageId]);

        Event::log('stage_changed', $opportunity->id, $opportunity->account_id, [
            'from' => $oldStage->name,
            'to' => $newStage->name,
            'days_in_previous' => $opportunity->daysInCurrentStage(),
        ]);

        return $opportunity->fresh();
    }

    /**
     * Marca como ganho.
     */
    public function markWon(Opportunity $opportunity, ?float $finalValue = null): Opportunity
    {
        $wonStage = Stage::where('is_won', true)->first();

        $updateData = [
            'status' => 'won',
            'won_at' => now(),
        ];

        if ($wonStage) {
            $updateData['stage_id'] = $wonStage->id;
        }

        if ($finalValue !== null) {
            $updateData['value_estimated'] = $finalValue;
        }

        $opportunity->update($updateData);

        Event::log('won', $opportunity->id, $opportunity->account_id, [
            'value' => $opportunity->value_estimated,
            'days_to_close' => (int) $opportunity->created_at->diffInDays(now()),
        ]);

        Log::info('CRM Oportunidade ganha', [
            'opportunity_id' => $opportunity->id,
            'value' => $opportunity->value_estimated,
        ]);

        return $opportunity->fresh();
    }

    /**
     * Marca como perdida.
     */
    public function markLost(Opportunity $opportunity, ?string $reason = null): Opportunity
    {
        $lostStage = Stage::where('is_lost', true)->first();

        $updateData = [
            'status' => 'lost',
            'lost_at' => now(),
            'lost_reason' => $reason,
        ];

        if ($lostStage) {
            $updateData['stage_id'] = $lostStage->id;
        }

        $opportunity->update($updateData);

        Event::log('lost', $opportunity->id, $opportunity->account_id, [
            'reason' => $reason,
            'days_to_close' => (int) $opportunity->created_at->diffInDays(now()),
        ]);

        Log::info('CRM Oportunidade perdida', [
            'opportunity_id' => $opportunity->id,
            'reason' => $reason,
        ]);

        return $opportunity->fresh();
    }

    /**
     * Atualiza campos da oportunidade.
     */
    public function update(Opportunity $opportunity, array $data): Opportunity
    {
        $fillable = ['title', 'area', 'source', 'value_estimated', 'owner_user_id', 'next_action_at'];
        $changes = [];

        foreach ($fillable as $field) {
            if (array_key_exists($field, $data) && $opportunity->{$field} != $data[$field]) {
                $changes[$field] = ['from' => $opportunity->{$field}, 'to' => $data[$field]];
            }
        }

        $opportunity->update(array_intersect_key($data, array_flip($fillable)));

        if (!empty($changes)) {
            Event::log('opportunity_updated', $opportunity->id, $opportunity->account_id, $changes);
        }

        return $opportunity->fresh();
    }
}
