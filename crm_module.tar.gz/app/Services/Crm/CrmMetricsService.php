<?php

namespace App\Services\Crm;

use App\Models\Crm\Opportunity;
use App\Models\Crm\Stage;
use App\Models\Crm\Event;
use App\Models\Crm\Account;
use App\Models\Crm\Activity;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CrmMetricsService
{
    /**
     * KPIs do pipeline para header do Kanban.
     */
    public function pipelineKPIs(array $filters = []): array
    {
        $query = Opportunity::query();
        $this->applyFilters($query, $filters);

        $baseQuery = clone $query;

        $openQuery = (clone $baseQuery)->where('status', 'open');
        $wonQuery  = (clone $baseQuery)->where('status', 'won');
        $lostQuery = (clone $baseQuery)->where('status', 'lost');

        $totalOpen = $openQuery->count();
        $totalWon  = $wonQuery->count();
        $totalLost = $lostQuery->count();
        $totalAll  = $totalOpen + $totalWon + $totalLost;

        $valorPipeline = (clone $baseQuery)->where('status', 'open')->sum('value_estimated') ?? 0;
        $valorGanho    = (clone $baseQuery)->where('status', 'won')->sum('value_estimated') ?? 0;

        $winRate = ($totalWon + $totalLost) > 0
            ? round(($totalWon / ($totalWon + $totalLost)) * 100, 1)
            : 0;

        $overdue = Opportunity::overdueNextAction()
            ->when(!empty($filters['owner']), fn($q) => $q->where('owner_user_id', $filters['owner']))
            ->count();

        return [
            'total_open' => $totalOpen,
            'total_won' => $totalWon,
            'total_lost' => $totalLost,
            'total_all' => $totalAll,
            'valor_pipeline' => $valorPipeline,
            'valor_ganho' => $valorGanho,
            'win_rate' => $winRate,
            'overdue' => $overdue,
        ];
    }

    /**
     * Relatórios detalhados para a view de reports.
     */
    public function reports(array $filters = []): array
    {
        return [
            'funnel' => $this->funnelReport($filters),
            'conversion_by_stage' => $this->conversionByStage($filters),
            'avg_time_by_stage' => $this->avgTimeByStage($filters),
            'win_rate_by_owner' => $this->winRateByOwner($filters),
            'lost_reasons' => $this->lostReasons($filters),
            'projected_revenue' => $this->projectedRevenue($filters),
        ];
    }

    /**
     * Funil: quantas oportunidades passaram por cada stage.
     */
    private function funnelReport(array $filters): array
    {
        $stages = Stage::active()->ordered()->get();
        $result = [];

        foreach ($stages as $stage) {
            $query = Opportunity::where('stage_id', $stage->id);
            $this->applyFilters($query, $filters);

            // Contar oportunidades que estão OU passaram por este estágio
            $currentCount = $query->count();

            // Contar também quem já passou (via events)
            $passedCount = Event::where('type', 'stage_changed')
                ->whereJsonContains('payload->to', $stage->name)
                ->when(!empty($filters['period_start']), function ($q) use ($filters) {
                    $q->where('happened_at', '>=', $filters['period_start']);
                })
                ->when(!empty($filters['period_end']), function ($q) use ($filters) {
                    $q->where('happened_at', '<=', $filters['period_end']);
                })
                ->distinct('opportunity_id')
                ->count('opportunity_id');

            $result[] = [
                'stage' => $stage->name,
                'color' => $stage->color,
                'current' => $currentCount,
                'passed' => $passedCount + $currentCount,
                'is_terminal' => $stage->isTerminal(),
            ];
        }

        return $result;
    }

    /**
     * Taxa de conversão entre etapas consecutivas.
     */
    private function conversionByStage(array $filters): array
    {
        $stages = Stage::active()->ordered()->where('is_won', false)->where('is_lost', false)->get();
        $result = [];

        for ($i = 0; $i < $stages->count() - 1; $i++) {
            $from = $stages[$i];
            $to = $stages[$i + 1];

            $fromCount = Event::where('type', 'stage_changed')
                ->where(function ($q) use ($from) {
                    $q->whereJsonContains('payload->from', $from->name)
                      ->orWhereJsonContains('payload->to', $from->name);
                })
                ->distinct('opportunity_id')
                ->count('opportunity_id');

            $toCount = Event::where('type', 'stage_changed')
                ->whereJsonContains('payload->to', $to->name)
                ->distinct('opportunity_id')
                ->count('opportunity_id');

            $rate = $fromCount > 0 ? round(($toCount / $fromCount) * 100, 1) : 0;

            $result[] = [
                'from' => $from->name,
                'to' => $to->name,
                'from_count' => $fromCount,
                'to_count' => $toCount,
                'rate' => $rate,
            ];
        }

        return $result;
    }

    /**
     * Tempo médio em cada estágio (dias).
     */
    private function avgTimeByStage(array $filters): array
    {
        $stages = Stage::active()->ordered()->get();
        $result = [];

        foreach ($stages as $stage) {
            if ($stage->isTerminal()) {
                continue;
            }

            $avgDays = DB::table('crm_events')
                ->where('type', 'stage_changed')
                ->whereJsonContains('payload->from', $stage->name)
                ->whereNotNull('payload')
                ->avg(DB::raw("JSON_EXTRACT(payload, '$.days_in_previous')"));

            $result[] = [
                'stage' => $stage->name,
                'color' => $stage->color,
                'avg_days' => round((float) ($avgDays ?? 0), 1),
            ];
        }

        return $result;
    }

    /**
     * Win rate por responsável.
     */
    private function winRateByOwner(array $filters): array
    {
        return DB::table('crm_opportunities')
            ->join('users', 'crm_opportunities.owner_user_id', '=', 'users.id')
            ->whereIn('crm_opportunities.status', ['won', 'lost'])
            ->when(!empty($filters['period_start']), function ($q) use ($filters) {
                $q->where('crm_opportunities.created_at', '>=', $filters['period_start']);
            })
            ->when(!empty($filters['period_end']), function ($q) use ($filters) {
                $q->where('crm_opportunities.created_at', '<=', $filters['period_end']);
            })
            ->groupBy('users.id', 'users.name')
            ->select(
                'users.name',
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN crm_opportunities.status = 'won' THEN 1 ELSE 0 END) as won"),
                DB::raw("SUM(CASE WHEN crm_opportunities.status = 'lost' THEN 1 ELSE 0 END) as lost"),
                DB::raw("ROUND(SUM(CASE WHEN crm_opportunities.status = 'won' THEN 1 ELSE 0 END) / COUNT(*) * 100, 1) as win_rate")
            )
            ->orderByDesc('win_rate')
            ->get()
            ->toArray();
    }

    /**
     * Motivos de perda agrupados.
     */
    private function lostReasons(array $filters): array
    {
        $query = Opportunity::where('status', 'lost')
            ->whereNotNull('lost_reason');

        $this->applyFilters($query, $filters);

        return $query->groupBy('lost_reason')
            ->select('lost_reason', DB::raw('COUNT(*) as count'))
            ->orderByDesc('count')
            ->limit(10)
            ->get()
            ->toArray();
    }

    /**
     * Receita projetada (oportunidades open * probabilidade implícita do stage).
     */
    private function projectedRevenue(array $filters): array
    {
        $stages = Stage::active()->ordered()
            ->where('is_won', false)->where('is_lost', false)
            ->get();

        $result = [];
        $totalProjected = 0;

        // Atribuir probabilidade implícita por posição no funil
        $stageCount = $stages->count();
        foreach ($stages as $i => $stage) {
            $probability = $stageCount > 1
                ? round((($i + 1) / $stageCount) * 100)
                : 50;

            $query = Opportunity::where('stage_id', $stage->id)
                ->where('status', 'open');
            $this->applyFilters($query, $filters);

            $rawValue = $query->sum('value_estimated') ?? 0;
            $projected = $rawValue * ($probability / 100);
            $totalProjected += $projected;

            $result[] = [
                'stage' => $stage->name,
                'color' => $stage->color,
                'count' => (clone $query)->count(),
                'raw_value' => $rawValue,
                'probability' => $probability,
                'projected' => round($projected, 2),
            ];
        }

        return [
            'stages' => $result,
            'total_projected' => round($totalProjected, 2),
        ];
    }

    /**
     * Aplica filtros comuns.
     */
    private function applyFilters($query, array $filters): void
    {
        if (!empty($filters['owner'])) {
            $query->where('owner_user_id', $filters['owner']);
        }
        if (!empty($filters['source'])) {
            $query->where('source', $filters['source']);
        }
        if (!empty($filters['stage_id'])) {
            $query->where('stage_id', $filters['stage_id']);
        }
        if (!empty($filters['period_start'])) {
            $query->where('created_at', '>=', $filters['period_start']);
        }
        if (!empty($filters['period_end'])) {
            $query->where('created_at', '<=', $filters['period_end']);
        }
    }
}
