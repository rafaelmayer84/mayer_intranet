<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('crm_events', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('opportunity_id')->nullable();
            $table->unsignedBigInteger('account_id')->nullable();
            $table->string('type', 100)->comment('stage_changed, activity_created, won, lost, note, nexo_opened_chat, lead_linked');
            $table->json('payload')->nullable();
            $table->dateTime('happened_at');
            $table->unsignedBigInteger('created_by_user_id')->nullable();
            $table->timestamps();

            $table->foreign('opportunity_id')
                  ->references('id')->on('crm_opportunities')
                  ->onDelete('cascade');

            $table->foreign('account_id')
                  ->references('id')->on('crm_accounts')
                  ->onDelete('cascade');

            $table->index('happened_at');
            $table->index('type');
            $table->index(['opportunity_id', 'happened_at']);
            $table->index(['account_id', 'happened_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_events');
    }
};
