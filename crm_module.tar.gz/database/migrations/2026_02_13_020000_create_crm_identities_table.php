<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('crm_identities', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('account_id');
            $table->enum('kind', ['phone', 'email', 'doc', 'datajuri', 'sendpulse', 'espocrm']);
            $table->string('value', 255);
            $table->string('value_norm', 255)->comment('Valor normalizado para busca');
            $table->timestamps();

            $table->foreign('account_id')
                  ->references('id')->on('crm_accounts')
                  ->onDelete('cascade');

            $table->unique(['kind', 'value_norm'], 'uq_crm_identity_kind_norm');
            $table->index('account_id');
            $table->index('value_norm');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_identities');
    }
};
