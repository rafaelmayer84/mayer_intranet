<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('crm_opportunities', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('account_id');
            $table->unsignedBigInteger('stage_id');
            $table->string('title', 255);
            $table->string('area', 100)->nullable()->comment('Area do Direito');
            $table->string('source', 100)->nullable()->comment('lead, indicacao, site, whatsapp, etc');
            $table->decimal('value_estimated', 12, 2)->nullable();
            $table->unsignedBigInteger('owner_user_id')->nullable();
            $table->dateTime('next_action_at')->nullable();
            $table->enum('status', ['open', 'won', 'lost'])->default('open');
            $table->string('lost_reason', 255)->nullable();
            $table->dateTime('won_at')->nullable();
            $table->dateTime('lost_at')->nullable();
            $table->unsignedBigInteger('lead_id')->nullable()->comment('Lead de origem se houver');
            $table->timestamps();

            $table->foreign('account_id')
                  ->references('id')->on('crm_accounts')
                  ->onDelete('cascade');

            $table->foreign('stage_id')
                  ->references('id')->on('crm_stages')
                  ->onDelete('restrict');

            $table->index('status');
            $table->index('owner_user_id');
            $table->index('next_action_at');
            $table->index('lead_id');
            $table->index(['status', 'stage_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_opportunities');
    }
};
