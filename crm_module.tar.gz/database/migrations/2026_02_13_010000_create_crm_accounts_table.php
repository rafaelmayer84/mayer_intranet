<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('crm_accounts', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['PF', 'PJ'])->default('PF');
            $table->string('name', 255);
            $table->string('doc_digits', 20)->nullable()->comment('CPF/CNPJ somente digitos');
            $table->text('notes')->nullable();
            $table->unsignedBigInteger('owner_user_id')->nullable();
            $table->timestamps();

            $table->index('type');
            $table->index('owner_user_id');
            $table->index('name');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('crm_accounts');
    }
};
