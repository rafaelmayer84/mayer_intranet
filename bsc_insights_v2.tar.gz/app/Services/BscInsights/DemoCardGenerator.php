<?php

namespace App\Services\BscInsights;

use App\Models\BscInsightCard;
use App\Models\AiRun;
use Illuminate\Support\Facades\Log;

class DemoCardGenerator
{
    public function generate(AiRun $run, array $snapshot): array
    {
        $cards = [];
        $cardDefs = $this->buildCards($snapshot);

        foreach ($cardDefs as $def) {
            $cards[] = BscInsightCard::create([
                'ai_run_id'      => $run->id,
                'universo'       => $def['universo'],
                'severidade'     => $def['severidade'],
                'confidence'     => $def['confidence'],
                'title'          => $def['title'],
                'what_changed'   => $def['what_changed'],
                'why_it_matters' => $def['why_it_matters'],
                'evidences'      => $def['evidences'],
                'recommendation' => $def['recommendation'],
                'next_step'      => $def['next_step'],
                'questions'      => $def['questions'] ?? [],
                'dependencies'   => $def['dependencies'] ?? [],
                'evidence_keys'  => $def['evidence_keys'] ?? [],
                'impact_score'   => $def['impact_score'],
            ]);
        }

        $summary = $this->buildSummary($snapshot);

        $run->update([
            'status'             => 'success',
            'model'              => 'demo-mode',
            'input_tokens'       => 0,
            'output_tokens'      => 0,
            'total_tokens'       => 0,
            'estimated_cost_usd' => 0,
        ]);

        Log::info("BSC Insights DEMO: " . count($cards) . " cards gerados");

        return ['cards' => $cards, 'summary' => $summary];
    }

    private function buildCards(array $s): array
    {
        $cards = [];

        // === FINANCEIRO ===
        $fin = $s['finance'] ?? [];
        $inad = $s['inadimplencia'] ?? [];
        $series = $fin['series_mensal'] ?? [];
        $lastMonth = end($series) ?: [];
        $receitaTotal = $lastMonth['receita_total'] ?? 0;
        $despesaTotal = $lastMonth['despesa'] ?? 0;
        $resultado = $lastMonth['resultado'] ?? 0;
        $margemLiq = $receitaTotal > 0 ? round(($resultado / $receitaTotal) * 100, 1) : 0;
        $mixPf = $fin['mix_pf_pj']['pf_pct'] ?? 0;
        $mixPj = $fin['mix_pf_pj']['pj_pct'] ?? 0;
        $inadTotal = $inad['total_vencido'] ?? 0;
        $inadQtd = $inad['qtd_vencidas'] ?? 0;
        $inadDias = $inad['dias_medio_atraso'] ?? 0;

        // Card: Inadimplência
        if ($inadTotal > 0) {
            $cards[] = [
                'universo'       => 'FINANCEIRO',
                'severidade'     => $inadTotal > 500000 ? 'CRITICO' : 'ATENCAO',
                'confidence'     => 92,
                'title'          => $inadTotal > 500000
                    ? 'Inadimplência acima de R$ 500 mil exige ação imediata'
                    : 'Inadimplência acumulada precisa de atenção',
                'what_changed'   => 'São ' . $inadQtd . ' títulos vencidos com atraso médio de ' . $inadDias . ' dias. Cada mês sem cobrança ativa reduz a probabilidade de recuperação.',
                'why_it_matters' => 'Inadimplência prolongada compromete o fluxo de caixa e pode inviabilizar investimentos planejados.',
                'evidences'      => [
                    ['metric' => 'Total vencido', 'value' => 'R$ ' . number_format($inadTotal, 0, ',', '.')],
                    ['metric' => 'Títulos vencidos', 'value' => $inadQtd . ' títulos'],
                    ['metric' => 'Atraso médio', 'value' => $inadDias . ' dias'],
                ],
                'recommendation' => 'Priorizar cobrança dos 10 maiores devedores esta semana',
                'next_step'      => 'Gerar relatório de aging e agendar reunião com equipe de cobrança',
                'questions'      => ['Quais clientes têm mais de 180 dias de atraso?', 'Há acordos de pagamento em andamento?'],
                'evidence_keys'  => ['inadimplencia.total_vencido', 'inadimplencia.qtd_vencidas'],
                'impact_score'   => $inadTotal > 500000 ? 9 : 6,
            ];
        }

        // Card: Resultado operacional / margem
        if ($receitaTotal > 0) {
            $sev = $margemLiq < 15 ? 'ATENCAO' : 'INFO';
            $cards[] = [
                'universo'       => 'FINANCEIRO',
                'severidade'     => $sev,
                'confidence'     => 85,
                'title'          => $margemLiq < 15
                    ? 'Margem líquida de ' . $margemLiq . '% está abaixo do ideal para escritórios'
                    : 'Resultado positivo com margem de ' . $margemLiq . '%',
                'what_changed'   => 'O escritório gerou R$ ' . number_format($receitaTotal, 0, ',', '.') . ' de receita com R$ ' . number_format($despesaTotal, 0, ',', '.') . ' de despesas, resultando em ' . ($resultado >= 0 ? 'superávit' : 'déficit') . ' de R$ ' . number_format(abs($resultado), 0, ',', '.') . '.',
                'why_it_matters' => 'A margem líquida é o termômetro da saúde financeira. Abaixo de 20%, o escritório opera sem reserva para imprevistos.',
                'evidences'      => [
                    ['metric' => 'Resultado', 'value' => 'R$ ' . number_format($resultado, 0, ',', '.')],
                    ['metric' => 'Receita total', 'value' => 'R$ ' . number_format($receitaTotal, 0, ',', '.')],
                    ['metric' => 'Margem líquida', 'value' => $margemLiq . '%'],
                ],
                'recommendation' => $margemLiq < 15
                    ? 'Revisar os 5 maiores centros de custo e identificar cortes possíveis'
                    : 'Manter acompanhamento mensal e avaliar investimento em captação',
                'next_step'      => 'Comparar despesas dos últimos 3 meses para identificar tendência',
                'questions'      => ['Despesas estão crescendo mais rápido que receita?'],
                'evidence_keys'  => ['finance.series_mensal'],
                'impact_score'   => $margemLiq < 15 ? 7 : 4,
            ];
        }

        // Card: Mix PF/PJ
        if ($mixPf > 0 || $mixPj > 0) {
            $desequilibrado = abs($mixPf - $mixPj) > 30;
            $cards[] = [
                'universo'       => 'FINANCEIRO',
                'severidade'     => $desequilibrado ? 'ATENCAO' : 'INFO',
                'confidence'     => 78,
                'title'          => $desequilibrado
                    ? 'Concentração de receita em ' . ($mixPj > $mixPf ? 'PJ' : 'PF') . ' representa risco'
                    : 'Mix PF/PJ equilibrado — boa diversificação',
                'what_changed'   => 'A receita está distribuída em ' . $mixPf . '% PF e ' . $mixPj . '% PJ. ' . ($desequilibrado ? 'Alta concentração em uma categoria aumenta exposição a ciclos econômicos.' : 'Distribuição saudável reduz risco.'),
                'why_it_matters' => 'Diversificação de receita protege contra oscilações de mercado e dependência de poucos clientes.',
                'evidences'      => [
                    ['metric' => 'Participação', 'value' => $mixPf . '% PF · ' . $mixPj . '% PJ'],
                    ['metric' => 'PF', 'value' => $mixPf . '%'],
                    ['metric' => 'PJ', 'value' => $mixPj . '%'],
                ],
                'recommendation' => $desequilibrado
                    ? 'Criar campanha de captação para segmento ' . ($mixPf < $mixPj ? 'PF' : 'PJ')
                    : 'Manter estratégia atual de captação balanceada',
                'next_step'      => 'Analisar ticket médio por segmento para otimizar esforço comercial',
                'evidence_keys'  => ['finance.mix_pf_pj'],
                'impact_score'   => $desequilibrado ? 5 : 3,
            ];
        }

        // === CLIENTES & MERCADO ===
        $cli = $s['clientes'] ?? [];
        $leads = $s['leads'] ?? [];
        $crm = $s['crm'] ?? [];
        $totalClientes = $cli['total'] ?? 0;
        $novosUltimoMes = 0;
        $seriesCli = $cli['novos_por_mes'] ?? [];
        if (!empty($seriesCli)) { $novosUltimoMes = end($seriesCli)['total'] ?? 0; }
        $totalLeads = $leads['total'] ?? 0;
        $winRate = $crm['win_rate'] ?? 0;
        $opOpen = $crm['oportunidades']['open'] ?? 0;
        $pipelineVal = $crm['valor_pipeline'] ?? 0;

        // Card: Pipeline CRM
        if ($opOpen > 0) {
            $cards[] = [
                'universo'       => 'CLIENTES_MERCADO',
                'severidade'     => $winRate < 30 ? 'ATENCAO' : 'INFO',
                'confidence'     => 80,
                'title'          => $winRate < 30
                    ? 'Taxa de conversão de ' . $winRate . '% indica gargalo comercial'
                    : $opOpen . ' oportunidades abertas com R$ ' . number_format($pipelineVal, 0, ',', '.') . ' no pipeline',
                'what_changed'   => 'O pipeline tem ' . $opOpen . ' oportunidades ativas. ' . ($winRate < 30 ? 'Menos de 1 em 3 se converte em contrato — há espaço para melhorar o processo de venda.' : 'A conversão está em ' . $winRate . '%, compatível com o mercado jurídico.'),
                'why_it_matters' => 'Cada ponto percentual de melhoria na conversão representa receita adicional sem custo de captação.',
                'evidences'      => [
                    ['metric' => 'Pipeline', 'value' => 'R$ ' . number_format($pipelineVal, 0, ',', '.')],
                    ['metric' => 'Oportunidades', 'value' => $opOpen . ' abertas'],
                    ['metric' => 'Win rate', 'value' => $winRate . '%'],
                ],
                'recommendation' => $winRate < 30 ? 'Implementar follow-up estruturado nas oportunidades paradas há mais de 7 dias' : 'Focar em aumentar volume de leads qualificados',
                'next_step'      => 'Revisar oportunidades sem atividade recente no CRM',
                'questions'      => ['Qual o tempo médio do ciclo de venda?', 'Quais áreas jurídicas convertem melhor?'],
                'evidence_keys'  => ['crm.oportunidades', 'crm.win_rate'],
                'impact_score'   => $winRate < 30 ? 7 : 5,
            ];
        }

        // Card: Captação de leads
        $leadsMensal = $leads['leads_por_mes'] ?? [];
        $leadsUltimo = !empty($leadsMensal) ? end($leadsMensal)['total'] ?? 0 : 0;
        $cards[] = [
            'universo'       => 'CLIENTES_MERCADO',
            'severidade'     => $leadsUltimo < 10 ? 'ATENCAO' : 'INFO',
            'confidence'     => 75,
            'title'          => $leadsUltimo < 10
                ? 'Apenas ' . $leadsUltimo . ' leads no último mês — captação insuficiente'
                : $leadsUltimo . ' leads captados — funil ativo',
            'what_changed'   => 'O escritório captou ' . $leadsUltimo . ' leads no último mês via WhatsApp. ' . ($leadsUltimo < 10 ? 'Volume baixo pode indicar problema na campanha ou sazonalidade.' : 'Volume adequado para manter pipeline saudável.'),
            'why_it_matters' => 'Sem fluxo constante de leads, o pipeline seca em 2-3 meses e a receita futura é comprometida.',
            'evidences'      => [
                ['metric' => 'Leads último mês', 'value' => $leadsUltimo . ' leads'],
                ['metric' => 'Total acumulado', 'value' => $totalLeads . ' leads'],
            ],
            'recommendation' => $leadsUltimo < 10 ? 'Revisar campanhas ativas e testar novo canal de aquisição' : 'Manter investimento atual e otimizar qualificação',
            'next_step'      => 'Analisar fonte dos leads para identificar canal mais eficiente',
            'evidence_keys'  => ['leads.leads_por_mes'],
            'impact_score'   => $leadsUltimo < 10 ? 6 : 4,
        ];

        // Card: Base de clientes
        $cards[] = [
            'universo'       => 'CLIENTES_MERCADO',
            'severidade'     => 'INFO',
            'confidence'     => 90,
            'title'          => number_format($totalClientes, 0, ',', '.') . ' clientes na base — ' . $novosUltimoMes . ' novos no último mês',
            'what_changed'   => $novosUltimoMes > 0
                ? 'A base continua crescendo com ' . $novosUltimoMes . ' novos clientes cadastrados. Acompanhe a relação entre novos clientes e receita incremental.'
                : 'Nenhum novo cliente cadastrado no último mês. Pode ser um reflexo do ciclo de vendas ou da sazonalidade.',
            'why_it_matters' => 'O crescimento da base é indicador antecedente de receita futura.',
            'evidences'      => [
                ['metric' => 'Base total', 'value' => number_format($totalClientes, 0, ',', '.') . ' clientes'],
                ['metric' => 'Novos (mês)', 'value' => $novosUltimoMes],
            ],
            'recommendation' => 'Mapear lifetime value por segmento para direcionar investimento de captação',
            'next_step'      => 'Cruzar base de clientes com receita por cliente',
            'evidence_keys'  => ['clientes.total', 'clientes.novos_por_mes'],
            'impact_score'   => 3,
        ];

        // === PROCESSOS INTERNOS ===
        $proc = $s['processos'] ?? [];
        $totalAtivos = $proc['ativos'] ?? 0;
        $parados90d = $proc['sem_movimentacao_90d'] ?? 0;
        $encerrados = $proc['encerrados'] ?? 0;

        // Card: Processos parados
        if ($parados90d > 0) {
            $pctParados = $totalAtivos > 0 ? round(($parados90d / $totalAtivos) * 100, 1) : 0;
            $cards[] = [
                'universo'       => 'PROCESSOS_INTERNOS',
                'severidade'     => $pctParados > 20 ? 'CRITICO' : 'ATENCAO',
                'confidence'     => 95,
                'title'          => $parados90d . ' processos sem movimentação há 90+ dias (' . $pctParados . '% do acervo)',
                'what_changed'   => 'Processos parados representam risco de perda de prazo, insatisfação do cliente e potencial responsabilidade profissional. ' . ($pctParados > 20 ? 'O percentual está alto para um escritório ativo.' : 'Nível controlável, mas requer monitoramento.'),
                'why_it_matters' => 'Cliente sem retorno é o principal motivo de perda de carteira. Cada processo parado é um risco reputacional.',
                'evidences'      => [
                    ['metric' => 'Processos parados', 'value' => $parados90d . ' processos'],
                    ['metric' => 'Do acervo ativo', 'value' => $pctParados . '%'],
                    ['metric' => 'Acervo total', 'value' => $totalAtivos . ' ativos'],
                ],
                'recommendation' => 'Distribuir lista de processos parados entre advogados com prazo de 5 dias para atualização',
                'next_step'      => 'Extrair relatório de processos sem movimentação e atribuir responsáveis',
                'questions'      => ['Há processos aguardando decisão judicial?', 'Algum advogado está sobrecarregado?'],
                'evidence_keys'  => ['processos.sem_movimentacao_90d'],
                'impact_score'   => $pctParados > 20 ? 9 : 6,
            ];
        }

        // Card: Volume processual
        $cards[] = [
            'universo'       => 'PROCESSOS_INTERNOS',
            'severidade'     => 'INFO',
            'confidence'     => 88,
            'title'          => number_format($totalAtivos, 0, ',', '.') . ' processos ativos — acervo ' . ($totalAtivos > 1500 ? 'robusto' : 'em crescimento'),
            'what_changed'   => 'O escritório gerencia ' . $totalAtivos . ' processos ativos com ' . $encerrados . ' encerrados. A relação entre ativos e encerrados indica a velocidade de renovação do acervo.',
            'why_it_matters' => 'O volume do acervo impacta diretamente na necessidade de equipe e na receita recorrente.',
            'evidences'      => [
                ['metric' => 'Processos ativos', 'value' => number_format($totalAtivos, 0, ',', '.')],
                ['metric' => 'Encerrados', 'value' => number_format($encerrados, 0, ',', '.')],
            ],
            'recommendation' => 'Acompanhar relação novos/encerrados mensalmente para prever demanda de equipe',
            'next_step'      => 'Verificar distribuição por advogado para balancear carga',
            'evidence_keys'  => ['processos.ativos', 'processos.encerrados'],
            'impact_score'   => 4,
        ];

        // Card: Tickets
        $tickets = $s['tickets'] ?? [];
        $ticketsAbertos = $tickets['por_status']['aberto'] ?? 0;
        $ticketsTotal = $tickets['total'] ?? 0;
        if ($ticketsTotal > 0) {
            $cards[] = [
                'universo'       => 'PROCESSOS_INTERNOS',
                'severidade'     => $ticketsAbertos > 5 ? 'ATENCAO' : 'INFO',
                'confidence'     => 82,
                'title'          => $ticketsAbertos > 5
                    ? $ticketsAbertos . ' tickets abertos — fila de atendimento crescendo'
                    : 'Fila de tickets sob controle',
                'what_changed'   => $ticketsAbertos . ' tickets aguardam resolução de um total de ' . $ticketsTotal . '. ' . ($ticketsAbertos > 5 ? 'Acúmulo pode indicar falta de capacidade ou processos lentos de triagem.' : 'Volume gerenciável pela equipe.'),
                'why_it_matters' => 'Tickets são a voz do cliente. Cada ticket não resolvido pode virar uma reclamação.',
                'evidences'      => [
                    ['metric' => 'Tickets abertos', 'value' => $ticketsAbertos],
                    ['metric' => 'Total', 'value' => $ticketsTotal],
                ],
                'recommendation' => $ticketsAbertos > 5 ? 'Definir SLA de resposta e escalonar tickets antigos' : 'Manter cadência de resolução atual',
                'next_step'      => 'Categorizar tickets por tipo para identificar problemas recorrentes',
                'evidence_keys'  => ['tickets.por_status'],
                'impact_score'   => $ticketsAbertos > 5 ? 6 : 3,
            ];
        }

        // === TIMES & EVOLUÇÃO ===
        $horas = $s['horas'] ?? [];
        $atend = $s['atendimento'] ?? [];
        $horasSeries = $horas['horas_por_mes'] ?? [];
        $lastHoras = !empty($horasSeries) ? end($horasSeries)['horas'] ?? 0 : 0;
        $conversasTotal = $atend['total_conversas'] ?? 0;
        $semResposta = $atend['sem_resposta'] ?? 0;

        // Card: Horas trabalhadas
        if ($lastHoras > 0) {
            $cards[] = [
                'universo'       => 'TIMES_EVOLUCAO',
                'severidade'     => 'INFO',
                'confidence'     => 85,
                'title'          => number_format($lastHoras, 0, ',', '.') . 'h registradas no último mês',
                'what_changed'   => 'Foram registradas ' . number_format($lastHoras, 0, ',', '.') . ' horas de trabalho. Acompanhar este indicador permite identificar sobrecarga e otimizar alocação.',
                'why_it_matters' => 'Horas registradas são a base para precificação, produtividade e identificação de gargalos.',
                'evidences'      => [
                    ['metric' => 'Horas (mês)', 'value' => number_format($lastHoras, 0, ',', '.') . 'h'],
                    ['metric' => 'Total registros', 'value' => $horas['total_registros'] ?? 0],
                ],
                'recommendation' => 'Cruzar horas por advogado com receita para calcular produtividade individual',
                'next_step'      => 'Gerar ranking de produtividade (R$/hora) por profissional',
                'evidence_keys'  => ['horas.horas_por_mes'],
                'impact_score'   => 4,
            ];
        }

        // Card: WhatsApp sem resposta
        if ($semResposta > 0) {
            $cards[] = [
                'universo'       => 'TIMES_EVOLUCAO',
                'severidade'     => $semResposta > 10 ? 'CRITICO' : 'ATENCAO',
                'confidence'     => 90,
                'title'          => $semResposta . ' conversas WhatsApp sem resposta',
                'what_changed'   => 'Há ' . $semResposta . ' conversas de clientes aguardando resposta no WhatsApp. ' . ($semResposta > 10 ? 'Volume alto pode causar perda de clientes e má avaliação.' : 'Priorizar as mais antigas.'),
                'why_it_matters' => 'WhatsApp é o canal principal de contato. Silêncio prolongado é percebido como descaso.',
                'evidences'      => [
                    ['metric' => 'Sem resposta', 'value' => $semResposta . ' conversas'],
                    ['metric' => 'Total conversas', 'value' => $conversasTotal],
                ],
                'recommendation' => 'Atribuir responsável e responder todas em até 4 horas',
                'next_step'      => 'Verificar painel NEXO e priorizar conversas mais antigas',
                'evidence_keys'  => ['atendimento.sem_resposta'],
                'impact_score'   => $semResposta > 10 ? 8 : 5,
            ];
        }

        // Card: Adoção do sistema
        $cards[] = [
            'universo'       => 'TIMES_EVOLUCAO',
            'severidade'     => 'INFO',
            'confidence'     => 70,
            'title'          => 'Equipe usando ' . ($conversasTotal > 200 ? 'ativamente' : 'parcialmente') . ' os canais digitais',
            'what_changed'   => $conversasTotal . ' conversas WhatsApp e ' . ($horas['total_registros'] ?? 0) . ' registros de horas indicam ' . ($conversasTotal > 200 ? 'boa adoção dos canais digitais.' : 'oportunidade de aumentar o uso das ferramentas.'),
            'why_it_matters' => 'A maturidade digital do escritório depende do engajamento de toda a equipe com as ferramentas disponíveis.',
            'evidences'      => [
                ['metric' => 'Conversas WhatsApp', 'value' => $conversasTotal],
                ['metric' => 'Registros de horas', 'value' => $horas['total_registros'] ?? 0],
            ],
            'recommendation' => 'Incluir métricas de adoção na avaliação de desempenho (GDP)',
            'next_step'      => 'Identificar profissionais com baixo registro e oferecer treinamento',
            'evidence_keys'  => ['atendimento.total_conversas', 'horas.total_registros'],
            'impact_score'   => 3,
        ];

        return $cards;
    }

    private function buildSummary(array $s): array
    {
        $inad = $s['inadimplencia'] ?? [];
        $proc = $s['processos'] ?? [];
        $atend = $s['atendimento'] ?? [];
        $crm = $s['crm'] ?? [];
        $fin = $s['finance'] ?? [];
        $series = $fin['series_mensal'] ?? [];
        $last = end($series) ?: [];

        return [
            'principais_riscos' => array_filter([
                ($inad['total_vencido'] ?? 0) > 300000 ? 'Inadimplência de R$ ' . number_format($inad['total_vencido'] ?? 0, 0, ',', '.') . ' ameaça fluxo de caixa' : null,
                ($proc['sem_movimentacao_90d'] ?? 0) > 10 ? ($proc['sem_movimentacao_90d'] ?? 0) . ' processos parados podem gerar perda de prazo' : null,
                ($atend['sem_resposta'] ?? 0) > 5 ? ($atend['sem_resposta'] ?? 0) . ' clientes aguardando resposta no WhatsApp' : null,
            ]),
            'principais_oportunidades' => array_filter([
                ($crm['valor_pipeline'] ?? 0) > 0 ? 'R$ ' . number_format($crm['valor_pipeline'] ?? 0, 0, ',', '.') . ' no pipeline aguardando conversão' : null,
                'Automação de cobrança pode recuperar até 30% da inadimplência',
                'Ranking de produtividade (GDP) pode alinhar incentivos com resultado',
            ]),
            'apostas_recomendadas' => [
                ['descricao' => 'Campanha de cobrança ativa nos 20 maiores devedores', 'impacto_esperado' => 'Recuperar R$ 100-200 mil em 60 dias', 'esforco' => 'Médio'],
                ['descricao' => 'Follow-up estruturado nas oportunidades CRM abertas', 'impacto_esperado' => 'Aumentar conversão em 5-10 pontos percentuais', 'esforco' => 'Baixo'],
                ['descricao' => 'SLA de resposta WhatsApp de 4 horas', 'impacto_esperado' => 'Reduzir reclamações e aumentar retenção', 'esforco' => 'Baixo'],
            ],
        ];
    }
}
