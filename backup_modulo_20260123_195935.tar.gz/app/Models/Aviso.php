<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class Aviso extends Model
{
    use HasFactory;

    protected $table = 'avisos';

    protected $fillable = [
        'titulo',
        'descricao',
        'categoria_id',
        'prioridade',
        'status',
        'data_inicio',
        'data_fim',
        'destaque',
        'criado_por',
    ];

    protected $casts = [
        'data_inicio' => 'datetime',
        'data_fim' => 'datetime',
        'destaque' => 'boolean',
    ];

    public function categoria()
    {
        return $this->belongsTo(CategoriaAviso::class, 'categoria_id');
    }

    /**
     * Alias usado em alguns patches/controllers/views.
     */
    public function autor()
    {
        return $this->belongsTo(User::class, 'criado_por');
    }

    /**
     * Alias mais antigo (mantido por compatibilidade).
     */
    public function criadoPor()
    {
        return $this->autor();
    }

    public function registrosLeitura()
    {
        return $this->hasMany(AvisoLido::class, 'aviso_id');
    }

    public function usuariosLidos()
    {
        return $this->belongsToMany(User::class, 'avisos_lidos', 'aviso_id', 'usuario_id')
            ->withPivot(['lido_em']);
    }

    public function isVencido(): bool
    {
        return $this->data_fim instanceof Carbon ? $this->data_fim->isPast() : false;
    }

    public function isAgendado(): bool
    {
        if ($this->status !== 'agendado') return false;
        return $this->data_inicio instanceof Carbon ? $this->data_inicio->isFuture() : true;
    }

    public function isAtivo(): bool
    {
        if ($this->status !== 'ativo') return false;

        $now = now();

        if ($this->data_inicio && $this->data_inicio->gt($now)) return false;
        if ($this->data_fim && $this->data_fim->lt($now)) return false;

        return true;
    }

    public function getPrioridadeLabel(): string
    {
        return match ($this->prioridade) {
            'critica' => 'Crítica',
            'alta' => 'Alta',
            'media' => 'Média',
            'baixa' => 'Baixa',
            default => ucfirst((string) $this->prioridade),
        };
    }

    public function getPrioridadeIcone(): string
    {
        return match ($this->prioridade) {
            'critica' => '🔴',
            'alta' => '🟠',
            'media' => '🟡',
            'baixa' => '🟢',
            default => 'ℹ️',
        };
    }

    public function getPrioridadeCorHex(): string
    {
        return match ($this->prioridade) {
            'critica' => '#EF4444',
            'alta' => '#F97316',
            'media' => '#FBBF24',
            'baixa' => '#10B981',
            default => '#3B82F6',
        };
    }
}
