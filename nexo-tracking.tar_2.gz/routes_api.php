
// ═══════════════════════════════════════════════════════════════
// ROTAS PARA TRACKING DE WHATSAPP - NEXO
// ═══════════════════════════════════════════════════════════════

use App\Http\Controllers\Nexo\NexoTrackingController;

// ────────────────────────────────────────────────────────────────
// Endpoint público (sem autenticação) para receber tracking
// ────────────────────────────────────────────────────────────────

Route::post('nexo/api/pre-track-whatsapp-lead', [
    NexoTrackingController::class, 
    'preTrackWhatsAppLead'
])->name('nexo.pre-track-whatsapp');

// ────────────────────────────────────────────────────────────────
// NOTA DE SEGURANÇA:
// ────────────────────────────────────────────────────────────────
// 
// Este endpoint é público porque precisa ser chamado do JavaScript
// no site. Para evitar spam:
// 
// 1. Adicione rate limiting:
//    ->middleware('throttle:60,1')
// 
// 2. Adicione validação de origem (CORS):
//    ->middleware('cors:mayeradvogados.adv.br')
// 
// 3. Adicione verificação de CSRF se necessário
// 
// Exemplo com rate limit:

Route::post('nexo/api/pre-track-whatsapp-lead', [
    NexoTrackingController::class, 
    'preTrackWhatsAppLead'
])
->middleware('throttle:60,1') // Máximo 60 requests por minuto
->name('nexo.pre-track-whatsapp');
