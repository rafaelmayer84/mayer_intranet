# Scripts Executáveis - NEXO WhatsApp Tracking

## 🚀 Scripts Via SSH

### patch_webhook.php ⚡
**Aplica o patch automaticamente no NexoWebhookController**

```bash
# Dry-run (visualiza sem modificar)
php patch_webhook.php --dry-run

# Aplicar patch (com backup automático)
php patch_webhook.php
```

**Funcionalidades:**
- ✅ Localiza automaticamente `WaConversation::create()`
- ✅ Backup automático com timestamp
- ✅ Insere código de tracking
- ✅ Adiciona método `normalizePhoneForTracking()`
- ✅ Valida sintaxe PHP
- ✅ Rollback automático em caso de erro
- ✅ Detecta se já foi patcheado (evita duplicação)

---

### rollback_webhook.php 🔄
**Reverte o patch para estado anterior**

```bash
php rollback_webhook.php
```

**Funcionalidades:**
- ✅ Lista todos os backups disponíveis
- ✅ Permite escolher qual versão restaurar
- ✅ Backup do estado atual antes de restaurar
- ✅ Valida sintaxe após rollback
- ✅ Interface interativa

---

## 📦 Ordem de Execução Recomendada

```bash
# 1. Migration (criar tabelas)
php artisan migrate

# 2. Controller + Rotas (copiar arquivos manualmente)
# NexoTrackingController.php → app/Http/Controllers/Nexo/
# routes_api.php → adicionar em routes/api.php

# 3. Patch do Webhook (AUTOMÁTICO)
php patch_webhook.php

# 4. JavaScript no site (WPCode)
# Copiar whatsapp-tracking.js

# 5. Cleanup Command (opcional)
# CleanupTrackingCommand.php → app/Console/Commands/
```

---

## ⚠️ Importante

**Antes de executar `patch_webhook.php`:**
1. Verifique o caminho em `$controllerPath` (linha 25)
2. Execute primeiro com `--dry-run`
3. Confirme que o arquivo correto foi encontrado

**Padrões de busca:**
- `$conversation = WaConversation::create(...);`
- `$conversation = new WaConversation(...); $conversation->save();`

**Backups criados:**
- Formato: `NexoWebhookController.php.backup.YYYY-MM-DD_HHmmss`
- Localização: Mesmo diretório do controller
- Preservados indefinidamente (deletar manualmente se necessário)
