/**
 * ═══════════════════════════════════════════════════════════════
 * NEXO - WhatsApp Lead Tracking
 * ═══════════════════════════════════════════════════════════════
 * 
 * Captura GCLID/UTMs da URL e envia para NEXO antes de redirecionar
 * para WhatsApp. Invisível para o usuário.
 * 
 * INSTALAÇÃO: WPCode → Add Snippet → Custom Code (JavaScript)
 * LOCAL: Footer (executa em todas as páginas)
 */

(function() {
    'use strict';
    
    // ═══════════════════════════════════════════════════════════
    // CONFIGURAÇÃO
    // ═══════════════════════════════════════════════════════════
    
    const CONFIG = {
        // URL da API NEXO (ajuste conforme seu ambiente)
        apiUrl: 'https://intranet.mayeradvogados.adv.br/nexo/api/pre-track-whatsapp-lead',
        
        // Tempo máximo de espera para o tracking (ms)
        timeout: 1000,
        
        // Validade do tracking no localStorage (dias)
        storageDays: 30,
        
        // Nome da chave no localStorage
        storageKey: 'nexo_tracking_data'
    };
    
    // ═══════════════════════════════════════════════════════════
    // CAPTURA DE PARÂMETROS DA URL
    // ═══════════════════════════════════════════════════════════
    
    function captureTrackingData() {
        const params = new URLSearchParams(window.location.search);
        
        const tracking = {
            gclid: params.get('gclid') || null,
            fbclid: params.get('fbclid') || null,
            utm_source: params.get('utm_source') || null,
            utm_medium: params.get('utm_medium') || null,
            utm_campaign: params.get('utm_campaign') || null,
            utm_content: params.get('utm_content') || null,
            utm_term: params.get('utm_term') || null,
            referrer_url: document.referrer || null,
            landing_page: window.location.href,
            timestamp: Date.now()
        };
        
        // Só salva se tiver pelo menos um parâmetro relevante
        const hasData = tracking.gclid || tracking.fbclid || 
                       tracking.utm_source || tracking.utm_medium;
        
        if (hasData) {
            saveToLocalStorage(tracking);
        }
        
        return tracking;
    }
    
    // ═══════════════════════════════════════════════════════════
    // ARMAZENAMENTO LOCAL
    // ═══════════════════════════════════════════════════════════
    
    function saveToLocalStorage(data) {
        try {
            const expiryTime = Date.now() + (CONFIG.storageDays * 24 * 60 * 60 * 1000);
            const storageData = {
                data: data,
                expiry: expiryTime
            };
            localStorage.setItem(CONFIG.storageKey, JSON.stringify(storageData));
        } catch (e) {
            console.warn('NEXO Tracking: localStorage não disponível', e);
        }
    }
    
    function getFromLocalStorage() {
        try {
            const stored = localStorage.getItem(CONFIG.storageKey);
            if (!stored) return null;
            
            const storageData = JSON.parse(stored);
            
            // Verifica se expirou
            if (Date.now() > storageData.expiry) {
                localStorage.removeItem(CONFIG.storageKey);
                return null;
            }
            
            return storageData.data;
        } catch (e) {
            console.warn('NEXO Tracking: erro ao ler localStorage', e);
            return null;
        }
    }
    
    // ═══════════════════════════════════════════════════════════
    // EXTRAÇÃO DE TELEFONE DO LINK WHATSAPP
    // ═══════════════════════════════════════════════════════════
    
    function extractPhoneFromWhatsAppLink(url) {
        // Formatos suportados:
        // wa.me/5547999999999
        // wa.me/5547999999999?text=Olá
        // api.whatsapp.com/send?phone=5547999999999
        
        try {
            const urlObj = new URL(url);
            
            // wa.me/PHONE
            if (urlObj.hostname.includes('wa.me')) {
                const phone = urlObj.pathname.replace(/^\//, '').split('?')[0];
                return phone || null;
            }
            
            // api.whatsapp.com/send?phone=PHONE
            if (urlObj.hostname.includes('whatsapp.com')) {
                return urlObj.searchParams.get('phone') || null;
            }
            
            return null;
        } catch (e) {
            console.warn('NEXO Tracking: erro ao extrair telefone', e);
            return null;
        }
    }
    
    // ═══════════════════════════════════════════════════════════
    // ENVIO PARA API NEXO
    // ═══════════════════════════════════════════════════════════
    
    async function sendTrackingToNexo(phone, trackingData) {
        const payload = {
            phone: phone,
            gclid: trackingData.gclid,
            fbclid: trackingData.fbclid,
            utm_source: trackingData.utm_source,
            utm_medium: trackingData.utm_medium,
            utm_campaign: trackingData.utm_campaign,
            utm_content: trackingData.utm_content,
            utm_term: trackingData.utm_term,
            referrer_url: trackingData.referrer_url,
            landing_page: trackingData.landing_page
        };
        
        try {
            const response = await fetch(CONFIG.apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.warn('NEXO Tracking: erro ao enviar dados', error);
            // Não bloqueia o usuário se API falhar
            return null;
        }
    }
    
    // ═══════════════════════════════════════════════════════════
    // INTERCEPTAÇÃO DE CLIQUES EM LINKS WHATSAPP
    // ═══════════════════════════════════════════════════════════
    
    function interceptWhatsAppLinks() {
        document.addEventListener('click', async function(event) {
            // Procura o link clicado ou seu ancestral
            let target = event.target;
            while (target && target.tagName !== 'A') {
                target = target.parentElement;
            }
            
            if (!target || target.tagName !== 'A') return;
            
            const href = target.href;
            if (!href || (!href.includes('wa.me') && !href.includes('whatsapp.com'))) {
                return;
            }
            
            // ─────────────────────────────────────────────────
            // É um link WhatsApp! Intercepta e processa
            // ─────────────────────────────────────────────────
            
            event.preventDefault();
            
            const phone = extractPhoneFromWhatsAppLink(href);
            if (!phone) {
                // Sem telefone, deixa seguir normalmente
                window.location.href = href;
                return;
            }
            
            const trackingData = getFromLocalStorage();
            if (!trackingData) {
                // Sem dados de tracking, deixa seguir normalmente
                window.location.href = href;
                return;
            }
            
            // Envia tracking para NEXO (com timeout)
            const timeoutPromise = new Promise(resolve => 
                setTimeout(() => resolve(null), CONFIG.timeout)
            );
            
            await Promise.race([
                sendTrackingToNexo(phone, trackingData),
                timeoutPromise
            ]);
            
            // Redireciona para WhatsApp
            window.location.href = href;
            
        }, true); // useCapture = true para pegar antes de outros handlers
    }
    
    // ═══════════════════════════════════════════════════════════
    // INICIALIZAÇÃO
    // ═══════════════════════════════════════════════════════════
    
    function init() {
        // Captura parâmetros da URL atual (se houver)
        captureTrackingData();
        
        // Intercepta todos os cliques em links WhatsApp
        interceptWhatsAppLinks();
    }
    
    // Executa quando DOM estiver pronto
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})();
