#!/usr/bin/env php
<?php

/**
 * ═══════════════════════════════════════════════════════════════
 * NEXO - Patch Automático do Webhook
 * ═══════════════════════════════════════════════════════════════
 * 
 * Executa via SSH:
 * php patch_webhook.php
 * 
 * Funcionalidade:
 * - Localiza NexoWebhookController.php
 * - Faz backup automático
 * - Insere código de tracking após criação de WaConversation
 * - Valida sintaxe PHP após patch
 * - Rollback automático em caso de erro
 */

class WebhookPatcher
{
    private string $controllerPath;
    private string $backupPath;
    private bool $dryRun = false;
    
    // ═══════════════════════════════════════════════════════════
    // Configuração
    // ═══════════════════════════════════════════════════════════
    
    public function __construct()
    {
        // Ajustar caminho conforme estrutura do projeto
        $this->controllerPath = __DIR__ . '/app/Http/Controllers/Nexo/NexoWebhookController.php';
        $this->backupPath = __DIR__ . '/app/Http/Controllers/Nexo/NexoWebhookController.php.backup.' . date('Y-m-d_His');
    }
    
    // ═══════════════════════════════════════════════════════════
    // Método principal
    // ═══════════════════════════════════════════════════════════
    
    public function run(array $args = []): int
    {
        echo "\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "NEXO - Patch Automático do Webhook\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "\n";
        
        // Parse argumentos
        $this->dryRun = in_array('--dry-run', $args);
        
        if ($this->dryRun) {
            echo "⚠️  DRY RUN MODE - Nenhuma alteração será feita\n\n";
        }
        
        // Validações
        if (!$this->validateController()) {
            return 1;
        }
        
        if (!$this->checkIfAlreadyPatched()) {
            echo "✓ Arquivo NÃO está patcheado (pode continuar)\n\n";
        } else {
            echo "⚠️  ATENÇÃO: Arquivo JÁ contém código de tracking!\n";
            echo "   Executar novamente causará duplicação de código.\n";
            echo "   Abortando por segurança.\n\n";
            return 1;
        }
        
        // Backup
        if (!$this->createBackup()) {
            return 1;
        }
        
        // Patch
        if (!$this->applyPatch()) {
            return 1;
        }
        
        // Validação
        if (!$this->validateSyntax()) {
            echo "\n❌ ERRO: Sintaxe PHP inválida após patch!\n";
            echo "   Executando rollback...\n";
            $this->rollback();
            return 1;
        }
        
        echo "\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "✅ PATCH APLICADO COM SUCESSO!\n";
        echo "═══════════════════════════════════════════════════════════\n";
        echo "\n";
        echo "Backup salvo em:\n";
        echo "  {$this->backupPath}\n";
        echo "\n";
        echo "Para reverter o patch:\n";
        echo "  php patch_webhook.php --rollback\n";
        echo "\n";
        
        return 0;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Validação do controller
    // ═══════════════════════════════════════════════════════════
    
    private function validateController(): bool
    {
        echo "Validando arquivo...\n";
        
        if (!file_exists($this->controllerPath)) {
            echo "❌ ERRO: Arquivo não encontrado!\n";
            echo "   Caminho: {$this->controllerPath}\n";
            echo "\n";
            echo "   Ajuste a variável \$controllerPath no início do script.\n";
            return false;
        }
        
        if (!is_readable($this->controllerPath)) {
            echo "❌ ERRO: Arquivo não pode ser lido!\n";
            echo "   Verifique permissões.\n";
            return false;
        }
        
        if (!is_writable($this->controllerPath)) {
            echo "❌ ERRO: Arquivo não pode ser escrito!\n";
            echo "   Verifique permissões.\n";
            return false;
        }
        
        $content = file_get_contents($this->controllerPath);
        
        if (strpos($content, 'WaConversation') === false) {
            echo "⚠️  AVISO: Arquivo não contém referências a WaConversation\n";
            echo "   Pode não ser o arquivo correto?\n";
            echo "\n";
            echo "   Pressione ENTER para continuar ou Ctrl+C para abortar: ";
            fgets(STDIN);
        }
        
        echo "✓ Arquivo validado\n";
        echo "  Caminho: {$this->controllerPath}\n";
        echo "  Tamanho: " . number_format(strlen($content)) . " bytes\n";
        echo "\n";
        
        return true;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Verifica se já foi patcheado
    // ═══════════════════════════════════════════════════════════
    
    private function checkIfAlreadyPatched(): bool
    {
        echo "Verificando se já foi patcheado...\n";
        
        $content = file_get_contents($this->controllerPath);
        
        // Procura por assinaturas do patch
        $signatures = [
            'normalizePhoneForTracking',
            'leads_tracking',
            'wa_conversation_sources',
            'NEXO Tracking: Origem salva'
        ];
        
        foreach ($signatures as $signature) {
            if (strpos($content, $signature) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Criar backup
    // ═══════════════════════════════════════════════════════════
    
    private function createBackup(): bool
    {
        if ($this->dryRun) {
            echo "Backup seria criado em:\n";
            echo "  {$this->backupPath}\n\n";
            return true;
        }
        
        echo "Criando backup...\n";
        
        if (!copy($this->controllerPath, $this->backupPath)) {
            echo "❌ ERRO: Não foi possível criar backup!\n";
            return false;
        }
        
        echo "✓ Backup criado\n";
        echo "  {$this->backupPath}\n\n";
        
        return true;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Aplicar patch
    // ═══════════════════════════════════════════════════════════
    
    private function applyPatch(): bool
    {
        echo "Aplicando patch...\n";
        
        $content = file_get_contents($this->controllerPath);
        
        // ───────────────────────────────────────────────────────
        // Estratégia 1: Buscar após WaConversation::create
        // ───────────────────────────────────────────────────────
        
        $pattern = '/(\$conversation\s*=\s*WaConversation::create\([^)]*\);)/s';
        
        if (preg_match($pattern, $content, $matches)) {
            echo "✓ Encontrado ponto de inserção (WaConversation::create)\n";
            
            $insertionPoint = $matches[0];
            $trackingCode = $this->getTrackingCode();
            $newCode = $insertionPoint . "\n\n" . $trackingCode;
            
            $newContent = preg_replace($pattern, $newCode, $content, 1);
            
        } else {
            echo "⚠️  Padrão WaConversation::create não encontrado\n";
            echo "   Tentando estratégia alternativa...\n";
            
            // ───────────────────────────────────────────────────
            // Estratégia 2: Buscar new WaConversation
            // ───────────────────────────────────────────────────
            
            $pattern2 = '/(\$conversation\s*=\s*new\s+WaConversation\([^;]*;[^}]*\$conversation->save\(\);)/s';
            
            if (preg_match($pattern2, $content, $matches)) {
                echo "✓ Encontrado ponto de inserção (new WaConversation)\n";
                
                $insertionPoint = $matches[0];
                $trackingCode = $this->getTrackingCode();
                $newCode = $insertionPoint . "\n\n" . $trackingCode;
                
                $newContent = preg_replace($pattern2, $newCode, $content, 1);
                
            } else {
                echo "❌ ERRO: Não foi possível localizar ponto de inserção!\n";
                echo "\n";
                echo "Padrões procurados:\n";
                echo "  1. \$conversation = WaConversation::create(...);\n";
                echo "  2. \$conversation = new WaConversation(...); \$conversation->save();\n";
                echo "\n";
                echo "Verifique manualmente o arquivo e ajuste o script.\n";
                return false;
            }
        }
        
        // ───────────────────────────────────────────────────────
        // Adicionar método auxiliar no final da classe
        // ───────────────────────────────────────────────────────
        
        $helperMethod = $this->getHelperMethod();
        
        // Encontra o último } da classe
        $lastBracePos = strrpos($newContent, '}');
        
        if ($lastBracePos === false) {
            echo "❌ ERRO: Não foi possível encontrar final da classe!\n";
            return false;
        }
        
        // Insere método antes do último }
        $newContent = substr($newContent, 0, $lastBracePos) . 
                     $helperMethod . "\n" . 
                     substr($newContent, $lastBracePos);
        
        // ───────────────────────────────────────────────────────
        // Salvar arquivo modificado
        // ───────────────────────────────────────────────────────
        
        if ($this->dryRun) {
            echo "\nDRY RUN: Alterações que seriam feitas:\n";
            echo "─────────────────────────────────────────────────────\n";
            echo "Tamanho original: " . number_format(strlen($content)) . " bytes\n";
            echo "Tamanho novo:     " . number_format(strlen($newContent)) . " bytes\n";
            echo "Diferença:        +" . number_format(strlen($newContent) - strlen($content)) . " bytes\n";
            echo "─────────────────────────────────────────────────────\n\n";
            return true;
        }
        
        if (!file_put_contents($this->controllerPath, $newContent)) {
            echo "❌ ERRO: Não foi possível salvar arquivo!\n";
            return false;
        }
        
        echo "✓ Patch aplicado\n";
        echo "  Bytes adicionados: +" . number_format(strlen($newContent) - strlen($content)) . "\n\n";
        
        return true;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Código de tracking a ser inserido
    // ═══════════════════════════════════════════════════════════
    
    private function getTrackingCode(): string
    {
        return <<<'PHP'
        // ════════════════════════════════════════════════════════════════
        // NEXO Tracking - Vincula origem de marketing à conversa
        // ════════════════════════════════════════════════════════════════
        
        try {
            $normalizedPhone = $this->normalizePhoneForTracking($conversation->phone);
            
            if ($normalizedPhone) {
                $tracking = \DB::table('leads_tracking')
                    ->where('phone', $normalizedPhone)
                    ->whereNull('matched_at')
                    ->orderBy('created_at', 'desc')
                    ->first();
                
                if ($tracking) {
                    $hasRelevantData = !empty($tracking->gclid) || 
                                      !empty($tracking->fbclid) || 
                                      !empty($tracking->utm_source) || 
                                      !empty($tracking->utm_medium);
                    
                    if ($hasRelevantData) {
                        \DB::table('wa_conversation_sources')->insert([
                            'conversation_id' => $conversation->id,
                            'gclid' => $tracking->gclid,
                            'fbclid' => $tracking->fbclid,
                            'utm_source' => $tracking->utm_source,
                            'utm_medium' => $tracking->utm_medium,
                            'utm_campaign' => $tracking->utm_campaign,
                            'utm_content' => $tracking->utm_content,
                            'utm_term' => $tracking->utm_term,
                            'referrer_url' => $tracking->referrer_url,
                            'landing_page' => $tracking->landing_page,
                            'created_at' => now()
                        ]);
                        
                        \DB::table('leads_tracking')
                            ->where('id', $tracking->id)
                            ->update(['matched_at' => now()]);
                        
                        \Log::info('NEXO Tracking: Origem salva', [
                            'conversation_id' => $conversation->id,
                            'tracking_id' => $tracking->id,
                            'gclid' => $tracking->gclid,
                            'utm_source' => $tracking->utm_source
                        ]);
                    }
                }
            }
        } catch (\Exception $e) {
            \Log::error('NEXO Tracking Error no Webhook: ' . $e->getMessage(), [
                'conversation_id' => $conversation->id ?? null,
                'phone' => $conversation->phone ?? null
            ]);
        }
PHP;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Método auxiliar a ser adicionado na classe
    // ═══════════════════════════════════════════════════════════
    
    private function getHelperMethod(): string
    {
        return <<<'PHP'
    
    /**
     * ════════════════════════════════════════════════════════════════
     * NEXO Tracking - Normaliza telefone para busca
     * ════════════════════════════════════════════════════════════════
     */
    private function normalizePhoneForTracking(?string $phone): ?string
    {
        if (empty($phone)) {
            return null;
        }
        
        $digits = preg_replace('/\D/', '', $phone);
        
        if (empty($digits)) {
            return null;
        }
        
        if (str_starts_with($digits, '55')) {
            return '+' . $digits;
        }
        
        if (str_starts_with($digits, '0')) {
            $digits = substr($digits, 1);
        }
        
        return '+55' . $digits;
    }
PHP;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Validar sintaxe PHP
    // ═══════════════════════════════════════════════════════════
    
    private function validateSyntax(): bool
    {
        if ($this->dryRun) {
            echo "Validação de sintaxe seria executada\n";
            return true;
        }
        
        echo "Validando sintaxe PHP...\n";
        
        $output = [];
        $returnCode = 0;
        
        exec("php -l " . escapeshellarg($this->controllerPath) . " 2>&1", $output, $returnCode);
        
        if ($returnCode !== 0) {
            echo "❌ Sintaxe inválida:\n";
            foreach ($output as $line) {
                echo "   $line\n";
            }
            return false;
        }
        
        echo "✓ Sintaxe válida\n";
        return true;
    }
    
    // ═══════════════════════════════════════════════════════════
    // Rollback
    // ═══════════════════════════════════════════════════════════
    
    private function rollback(): bool
    {
        echo "Restaurando backup...\n";
        
        if (!file_exists($this->backupPath)) {
            echo "❌ ERRO: Backup não encontrado!\n";
            return false;
        }
        
        if (!copy($this->backupPath, $this->controllerPath)) {
            echo "❌ ERRO: Não foi possível restaurar backup!\n";
            return false;
        }
        
        echo "✓ Backup restaurado\n";
        return true;
    }
}

// ═══════════════════════════════════════════════════════════════
// Execução
// ═══════════════════════════════════════════════════════════════

if (php_sapi_name() !== 'cli') {
    die("Este script deve ser executado via CLI\n");
}

$patcher = new WebhookPatcher();
$exitCode = $patcher->run($argv);

exit($exitCode);
