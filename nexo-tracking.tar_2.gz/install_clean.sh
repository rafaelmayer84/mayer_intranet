#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# NEXO WhatsApp Tracking - Instalação LIMPA
# ═══════════════════════════════════════════════════════════════

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "NEXO - Instalação LIMPA (remove tudo antes)"
echo "═══════════════════════════════════════════════════════════"
echo ""

# ────────────────────────────────────────────────────────────
# 0. LIMPAR ROTAS PRIMEIRO
# ────────────────────────────────────────────────────────────

echo "PASSO 0: Limpando routes/api.php..."

# Backup
cp routes/api.php routes/api.php.backup.$(date +%Y%m%d_%H%M%S)

# Remover TODAS as linhas relacionadas ao NexoTrackingController
grep -v "NexoTrackingController" routes/api.php > routes/api.php.temp
grep -v "pre-track-whatsapp-lead" routes/api.php.temp > routes/api.php.temp2
grep -v "nexo.pre-track-whatsapp" routes/api.php.temp2 > routes/api.php.temp3

mv routes/api.php.temp3 routes/api.php
rm -f routes/api.php.temp routes/api.php.temp2

echo "✓ Rotas antigas removidas"

# ────────────────────────────────────────────────────────────
# 1. Migration
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 1: Migration..."

cp create_whatsapp_tracking_tables.php \
   database/migrations/2026_02_09_000001_create_whatsapp_tracking_tables.php

php artisan migrate --force

if [ $? -ne 0 ]; then
    echo "✗ ERRO na migration"
    echo ""
    echo "Revertendo routes/api.php..."
    cp routes/api.php.backup.* routes/api.php
    exit 1
fi

echo "✓ Tabelas criadas/verificadas"

# ────────────────────────────────────────────────────────────
# 2. Controller
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 2: Controller..."

mkdir -p app/Http/Controllers/Nexo
cp NexoTrackingController.php app/Http/Controllers/Nexo/

echo "✓ Controller copiado"

# ────────────────────────────────────────────────────────────
# 3. Rotas (agora adicionar limpo)
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 3: Adicionando rotas limpas..."

echo "" >> routes/api.php
cat routes_api.php >> routes/api.php

php artisan route:clear
php artisan route:cache

echo "✓ Rotas adicionadas"

# ────────────────────────────────────────────────────────────
# 4. Cleanup Command
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 4: Cleanup command..."

mkdir -p app/Console/Commands
cp CleanupTrackingCommand.php app/Console/Commands/

echo "✓ Command copiado"

# ────────────────────────────────────────────────────────────
# 5. Scripts
# ────────────────────────────────────────────────────────────

echo ""
echo "PASSO 5: Scripts executáveis..."

cp patch_webhook.php .
cp rollback_webhook.php .
chmod +x patch_webhook.php rollback_webhook.php

echo "✓ Scripts prontos"

# ────────────────────────────────────────────────────────────
# FIM
# ────────────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ INSTALAÇÃO CONCLUÍDA!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "Próximos passos:"
echo ""
echo "1. Aplicar patch no webhook:"
echo "   php patch_webhook.php --dry-run"
echo "   php patch_webhook.php"
echo ""
echo "2. JavaScript no WordPress"
echo "   Arquivo: whatsapp-tracking.js"
echo ""
