<?php
/**
 * PATCH para routes/console.php
 * 
 * TRECHO A ADICIONAR (via Python patch) no final do arquivo,
 * ANTES do fechamento, junto com os outros schedules existentes.
 * 
 * NÃO é um arquivo standalone — é referência para o patch.
 */

// ─── NEXO QA: Pesquisa de Qualidade ───
// Amostragem semanal: segunda-feira 09:00 (America/Sao_Paulo)
use App\Models\NexoQaCampaign;
use App\Jobs\NexoQaWeeklySamplingJob;
use App\Jobs\NexoQaWeeklyAggregateJob;

Schedule::call(function () {
    $campaigns = NexoQaCampaign::active()->get();
    foreach ($campaigns as $campaign) {
        NexoQaWeeklySamplingJob::dispatch($campaign->id);
    }
})->weeklyOn(1, '09:00')
  ->timezone('America/Sao_Paulo')
  ->name('nexo-qa-weekly-sampling')
  ->withoutOverlapping();

// Agregação semanal: domingo 22:00 (consolida a semana que terminou)
Schedule::call(function () {
    $weekStart = now('America/Sao_Paulo')->startOfWeek(\Carbon\Carbon::MONDAY)->format('Y-m-d');
    NexoQaWeeklyAggregateJob::dispatch($weekStart);
})->weeklyOn(0, '22:00')
  ->timezone('America/Sao_Paulo')
  ->name('nexo-qa-weekly-aggregate')
  ->withoutOverlapping();
