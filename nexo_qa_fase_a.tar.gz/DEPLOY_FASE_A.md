# NEXO QA — Pesquisa de Qualidade | FASE A — Deploy
# Módulo: NEXO Qualidade de Atendimento
# Data: 22/02/2026
# Escopo: Banco + Models + Services + Jobs + Policy + Commands

## INVENTÁRIO DE ARQUIVOS (25 arquivos PHP novos)

### Migrations (6)
database/migrations/2026_02_22_000001_create_nexo_qa_campaigns_table.php
database/migrations/2026_02_22_000002_create_nexo_qa_sampled_targets_table.php
database/migrations/2026_02_22_000003_create_nexo_qa_responses_identity_table.php
database/migrations/2026_02_22_000004_create_nexo_qa_responses_content_table.php
database/migrations/2026_02_22_000005_create_nexo_qa_aggregates_weekly_table.php
database/migrations/2026_02_22_000006_add_qa_columns_to_gdp_snapshots_table.php

### Models (6)
app/Models/NexoQaCampaign.php
app/Models/NexoQaSampledTarget.php
app/Models/NexoQaResponseIdentity.php
app/Models/NexoQaResponseContent.php
app/Models/NexoQaAggregateWeekly.php

### Services (5)
app/Services/NexoQa/NexoQaResolverService.php
app/Services/NexoQa/NexoQaSamplingService.php
app/Services/NexoQa/NexoQaSurveyService.php
app/Services/NexoQa/NexoQaResponseProcessor.php
app/Services/NexoQa/NexoQaAggregationService.php

### Jobs (4)
app/Jobs/NexoQaWeeklySamplingJob.php
app/Jobs/NexoQaDispatchPendingJob.php
app/Jobs/NexoQaSendSurveyJob.php
app/Jobs/NexoQaWeeklyAggregateJob.php

### Policy (1)
app/Policies/NexoQaPolicy.php

### Commands (2)
app/Console/Commands/NexoQaSampleCommand.php
app/Console/Commands/NexoQaAggregateCommand.php

### Seeder (1)
database/seeders/NexoQaModuloSeeder.php

### Patch (1 referência, não é arquivo standalone)
_patches/console_php_schedule_patch.php → trecho para routes/console.php

## TABELAS CRIADAS
- nexo_qa_campaigns
- nexo_qa_sampled_targets
- nexo_qa_responses_identity
- nexo_qa_responses_content
- nexo_qa_aggregates_weekly
- gdp_snapshots (4 colunas adicionadas: qa_avg_score, qa_nps, qa_response_rate, qa_responses_count)

## MÓDULOS ESTÁVEIS NÃO ALTERADOS ✓
- NexoConsultaController ✓
- NexoAutoatendimentoController ✓
- ProcessChatIAJob ✓
- LeadController ✓
- GdpController ✓ (só adicionou colunas ao gdp_snapshots)
- layouts/app.blade.php ✓
- routes/api.php ✓ (será alterado só na Fase B com nova rota)
- routes/console.php (patch mínimo na Fase A)

## VARIÁVEL .env NECESSÁRIA (Fase B)
NEXO_QA_WEBHOOK_TOKEN=<gerar token seguro>

## COMANDOS ARTISAN NOVOS
- nexo:qa-sample {campaign_id?} → Amostragem manual
- nexo:qa-aggregate {week_start?} → Agregação manual
