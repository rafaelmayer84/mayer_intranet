<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Nexo\NexoAutomationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class NexoWebhookController extends Controller
{
    private NexoAutomationService $nexoService;

    public function __construct(NexoAutomationService $nexoService)
    {
        $this->nexoService = $nexoService;
    }

    public function identificarCliente(Request $request)
    {
        if (!$this->validarWebhook($request)) {
            return response()->json(['erro' => 'Não autorizado'], 401);
        }

        $request->validate(['telefone' => 'required|string']);

        try {
            $resultado = $this->nexoService->identificarCliente($request->telefone);
            return response()->json($resultado);
        } catch (\Exception $e) {
            Log::error('Erro identificarCliente', ['erro' => $e->getMessage()]);
            return response()->json(['erro' => 'Erro interno'], 500);
        }
    }

    public function perguntasAuth(Request $request)
    {
        if (!$this->validarWebhook($request)) {
            return response()->json(['erro' => 'Não autorizado'], 401);
        }

        $request->validate(['telefone' => 'required|string']);

        try {
            $resultado = $this->nexoService->gerarPerguntasAuth($request->telefone);
            return response()->json($resultado);
        } catch (\Exception $e) {
            Log::error('Erro perguntasAuth', ['erro' => $e->getMessage()]);
            return response()->json(['erro' => 'Erro interno'], 500);
        }
    }

    public function validarAuth(Request $request)
    {
        if (!$this->validarWebhook($request)) {
            return response()->json(['erro' => 'Não autorizado'], 401);
        }

        $request->validate([
            'telefone' => 'required|string',
            
            
            
        ]);

        try {
            $resultado = $this->nexoService->validarAuth(
                $request->telefone,
                $request->has('pergunta1_campo') ? $request->all() : ($request->respostas ?? [])
            );
            return response()->json($resultado);
        } catch (\Exception $e) {
            Log::error('Erro validarAuth', ['erro' => $e->getMessage()]);
            return response()->json(['erro' => 'Erro interno'], 500);
        }
    }

    public function consultaStatus(Request $request)
    {
        if (!$this->validarWebhook($request)) {
            return response()->json(['erro' => 'Não autorizado'], 401);
        }
        $request->validate(['telefone' => 'required|string']);
        try {
            $resultado = $this->nexoService->consultarStatusProcesso($request->telefone);
            return response()->json($resultado);
        } catch (\Exception $e) {
            Log::error('Erro consultaStatus', ['erro' => $e->getMessage()]);
            return response()->json(['erro' => 'Erro interno'], 500);
        }
    }

    public function consultaStatusProcesso(Request $request)
    {
        if (!$this->validarWebhook($request)) {
            return response()->json(['erro' => 'Não autorizado'], 401);
        }
        $request->validate(['telefone' => 'required|string', 'pasta' => 'required|string']);
        try {
            $resultado = $this->nexoService->consultarProcessoEspecifico($request->telefone, $request->pasta);
            return response()->json($resultado);
        } catch (\Exception $e) {
            Log::error('Erro consultaStatusProcesso', ['erro' => $e->getMessage()]);
            return response()->json(['erro' => 'Erro interno'], 500);
        }
    }

    private function validarWebhook(Request $request): bool
    {
        $token = $request->header('X-Sendpulse-Token');
        $expectedToken = config('services.sendpulse.webhook_token');
        
        if (!$token || $token !== $expectedToken) {
            Log::warning('Tentativa webhook não autorizada', [
                'ip' => $request->ip(),
                'token_recebido' => $token ? 'presente' : 'ausente'
            ]);
            return false;
        }
        
        return true;
    }
}
