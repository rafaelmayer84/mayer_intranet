<?php

use App\Http\Controllers\LeadController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Rotas da Central de Leads
|--------------------------------------------------------------------------
|
| WEBHOOK (público, protegido por secret):
| - POST /webhook/leads
|
| DASHBOARD (protegido por auth):
| - GET /leads
| - GET /leads/{lead}
| - POST /leads/{lead}/status
| - POST /leads/{lead}/reprocess
| - GET /api/leads/stats
|
*/

// Webhook SendPulse (sem auth, validação via secret)
Route::post('/webhook/leads', [LeadController::class, 'webhook'])->name('webhook.leads')->withoutMiddleware('csrf');

// Rotas protegidas por autenticação
Route::middleware(['auth'])->group(function () {
    
    // Dashboard principal
    Route::get('/leads', [LeadController::class, 'index'])->name('leads.index');
    
    // Detalhes do lead
    Route::get('/leads/{lead}', [LeadController::class, 'show'])->name('leads.show');
    
    // Atualizar status
    Route::post('/leads/{lead}/status', [LeadController::class, 'updateStatus'])->name('leads.updateStatus');
    
    // Reprocessar lead
    Route::post('/leads/{lead}/reprocess', [LeadController::class, 'reprocess'])->name('leads.reprocess');

    // Deletar lead
    Route::delete('/leads/{lead}', [LeadController::class, 'destroy'])->name('leads.destroy');
    
    // API de estatísticas
    Route::get('/api/leads/stats', [LeadController::class, 'stats'])->name('leads.stats');
});
