<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\LeadMessage;
use App\Services\LeadProcessingService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class LeadController extends Controller
{
    public function __construct(
        protected LeadProcessingService $leadService
    ) {
    }

    /**
     * Dashboard principal da Central de Leads
     */
    public function index(Request $request): View
    {
        // Filtros
        $filtroArea = $request->get('area', 'todos');
        $filtroCidade = $request->get('cidade', 'todos');
        $filtroPeriodo = $request->get('periodo', 'todos');
        $filtroIntencao = $request->get('intencao', 'todos');

        // Query base com filtros
        $query = Lead::query()
            ->area($filtroArea)
            ->cidade($filtroCidade)
            ->periodo($filtroPeriodo)
            ->intencao($filtroIntencao);

        // Estatísticas
        $totalLeads = $query->count();
        $leadsHoje = Lead::whereDate('data_entrada', today())->count();
        $leadsSemana = Lead::where('data_entrada', '>=', now()->subDays(7))->count();
        
        // Taxa de conversão (intenção = sim)
        $leadsSim = (clone $query)->where('intencao_contratar', 'sim')->count();
        $taxaConversao = $totalLeads > 0 ? round(($leadsSim / $totalLeads) * 100, 1) : 0;

        // Dados para gráficos
        $dadosArea = DB::table('leads')
            ->select('area_interesse', DB::raw('COUNT(*) as total'))
            ->whereNotNull('area_interesse')
            ->where('area_interesse', '!=', '')
            ->groupBy('area_interesse')
            ->orderByDesc('total')
            ->get();

        $dadosCidade = DB::table('leads')
            ->select('cidade', DB::raw('COUNT(*) as total'))
            ->whereNotNull('cidade')
            ->where('cidade', '!=', '')
            ->where('cidade', '!=', 'não informado')
            ->groupBy('cidade')
            ->orderByDesc('total')
            ->limit(10)
            ->get();

        // Palavras-chave mais frequentes
        $todasPalavras = [];
        $palavrasRaw = Lead::whereNotNull('palavras_chave')
            ->where('palavras_chave', '!=', '')
            ->pluck('palavras_chave');
        
        foreach ($palavrasRaw as $palavrasStr) {
            $palavras = explode(',', $palavrasStr);
            foreach ($palavras as $palavra) {
                $palavra = trim($palavra);
                if (!empty($palavra)) {
                    $todasPalavras[] = $palavra;
                }
            }
        }
        
        $contagemPalavras = array_count_values($todasPalavras);
        arsort($contagemPalavras);
        $topPalavras = array_slice($contagemPalavras, 0, 20, true);

        // Timeline (últimos 30 dias)
        $dadosTimeline = DB::table('leads')
            ->select(DB::raw('DATE(data_entrada) as data'), DB::raw('COUNT(*) as total'))
            ->where('data_entrada', '>=', now()->subDays(30))
            ->groupBy(DB::raw('DATE(data_entrada)'))
            ->orderBy('data')
            ->get();

        // Distribuição por intenção
        $dadosIntencao = DB::table('leads')
            ->select('intencao_contratar', DB::raw('COUNT(*) as total'))
            ->whereNotNull('intencao_contratar')
            ->where('intencao_contratar', '!=', '')
            ->groupBy('intencao_contratar')
            ->get();

        // Leads recentes (últimos 20)
        $leads = $query->orderByDesc('data_entrada')->limit(20)->get();

        // Opções para filtros
        $areas = Lead::whereNotNull('area_interesse')
            ->where('area_interesse', '!=', '')
            ->distinct()
            ->orderBy('area_interesse')
            ->pluck('area_interesse');

        $cidades = Lead::whereNotNull('cidade')
            ->where('cidade', '!=', '')
            ->where('cidade', '!=', 'não informado')
            ->distinct()
            ->orderBy('cidade')
            ->pluck('cidade');

        return view('leads.index', compact(
            'totalLeads',
            'leadsHoje',
            'leadsSemana',
            'taxaConversao',
            'dadosArea',
            'dadosCidade',
            'topPalavras',
            'dadosTimeline',
            'dadosIntencao',
            'leads',
            'areas',
            'cidades',
            'filtroArea',
            'filtroCidade',
            'filtroPeriodo',
            'filtroIntencao'
        ));
    }

    /**
     * Detalhes de um lead específico
     */
    public function show(Lead $lead): View
    {
        $lead->load('messages');
        return view('leads.show', compact('lead'));
    }

    /**
     * Webhook do SendPulse (sem autenticação Laravel)
     */
    public function webhook(Request $request): JsonResponse
    {
        // Validar secret
        $webhookSecret = $request->header('X-Webhook-Secret');
        $expectedSecret = config('services.sendpulse.webhook_secret');

        if ($expectedSecret && $webhookSecret && $webhookSecret !== $expectedSecret) {
            Log::warning('Webhook com secret inválido', [
                'ip' => $request->ip(),
                'received_secret' => $webhookSecret
            ]);

            return response()->json(['error' => 'Unauthorized'], 401);
        }

        Log::info('Webhook recebido', ['payload' => $request->all()]);

        try {
            $webhookData = $request->all();
            
            if (empty($webhookData)) {
                return response()->json(['error' => 'Empty payload'], 400);
            }

            // Processar lead
            $lead = $this->leadService->processLead($webhookData);

            if (!$lead) {
                return response()->json(['error' => 'Failed to process lead'], 500);
            }

            return response()->json([
                'success' => true,
                'lead_id' => $lead->id,
                'message' => 'Lead processado com sucesso'
            ], 200);

        } catch (\Exception $e) {
            Log::error('Erro no webhook', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Atualizar status do lead
     */
    public function updateStatus(Request $request, Lead $lead): JsonResponse
    {
        $request->validate([
            'status' => 'required|in:novo,contatado,qualificado,convertido,descartado'
        ]);

        $lead->update(['status' => $request->status]);

        return response()->json([
            'success' => true,
            'message' => 'Status atualizado com sucesso'
        ]);
    }

    /**
     * Reprocessar lead
     */
    public function reprocess(Lead $lead): JsonResponse
    {
        $success = $this->leadService->reprocessLead($lead);

        if ($success) {
            return response()->json([
                'success' => true,
                'message' => 'Lead reprocessado com sucesso',
                'lead' => $lead->fresh()
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Erro ao reprocessar lead',
            'error' => $lead->erro_processamento
        ], 500);
    }

    /**
     * Estatísticas para API
     */
    public function stats(): JsonResponse
    {
        $stats = [
            'total_leads' => Lead::count(),
            'hoje' => Lead::whereDate('data_entrada', today())->count(),
            'semana' => Lead::where('data_entrada', '>=', now()->subDays(7))->count(),
            'mes' => Lead::where('data_entrada', '>=', now()->subDays(30))->count(),
            'por_status' => Lead::select('status', DB::raw('COUNT(*) as total'))
                ->groupBy('status')
                ->pluck('total', 'status'),
            'por_intencao' => Lead::select('intencao_contratar', DB::raw('COUNT(*) as total'))
                ->groupBy('intencao_contratar')
                ->pluck('total', 'intencao_contratar'),
            'com_erro' => Lead::whereNotNull('erro_processamento')->count()
        ];

        return response()->json($stats);
    }

    public function destroy(Lead $lead): JsonResponse
    {
        $leadId = $lead->id;
        $lead->messages()->delete();
        $lead->delete();
        Log::info('Lead deletado', ['lead_id' => $leadId]);
        return response()->json(['success' => true, 'message' => 'Lead deletado com sucesso']);
    }
}
