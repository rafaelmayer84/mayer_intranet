<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * DataJuriSyncOrchestrator v2.0 - PATCH DEFINITIVO
 * 
 * Correções aplicadas:
 * 1. Removido removerHtml (quebrava API, retornava 0 rows)
 * 2. parseDecimal() agora trata HTML (<span class='valor-positivo'>)
 * 3. Extração de codigo_plano do planoConta.nomeCompleto via regex
 * 4. Classificação automática de movimentos via ClassificacaoService
 * 5. Auto-cleanup de sync_runs stuck (>30min)
 * 6. Tipo (receita/despesa) extraído de valorComSinal
 */
class DataJuriSyncOrchestrator
{
    protected string $baseUrl;
    protected string $clientId;
    protected string $clientSecret;
    protected string $username;
    protected string $password;
    protected int $timeout;
    protected int $retryAttempts;
    protected int $retryDelay;
    protected int $pageSize;
    protected ?string $accessToken = null;
    protected string $runId;
    protected array $config;
    
    public function __construct()
    {
        $this->config = config('datajuri');
        $this->baseUrl = $this->config['base_url'];
        $this->clientId = $this->config['client_id'];
        $this->clientSecret = $this->config['secret_id'];
        $this->timeout = $this->config['timeout'];
        $this->retryAttempts = $this->config['retry_attempts'];
        $this->retryDelay = $this->config['retry_delay'];
        $this->pageSize = $this->config['page_size'];
        $this->runId = (string) Str::uuid();
        
        // Credenciais OAuth Resource Owner Password (do config/services.php)
        $servicesConfig = config('services.datajuri', []);
        $this->username = $servicesConfig['email'] ?? $servicesConfig['username'] ?? '';
        $this->password = $servicesConfig['password'] ?? '';
    }
    
    /**
     * Obter token OAuth com cache e renovação automática
     */
    public function getAccessToken(): ?string
    {
        $cacheKey = 'datajuri_access_token';
        
        // Tentar cache primeiro
        if (Cache::has($cacheKey)) {
            $this->accessToken = Cache::get($cacheKey);
            return $this->accessToken;
        }
        
        // Gerar novo token
        $token = $this->requestNewToken();
        
        if ($token) {
            // Cache por 55 minutos (token expira em 60)
            Cache::put($cacheKey, $token, now()->addMinutes(55));
            $this->accessToken = $token;
        }
        
        return $this->accessToken;
    }
    
    /**
     * Solicitar novo token OAuth (Resource Owner Password Grant)
     */
    protected function requestNewToken(): ?string
    {
        $url = "{$this->baseUrl}/oauth/token";
        
        // Basic Auth: clientId:clientSecret
        $basic = base64_encode("{$this->clientId}:{$this->clientSecret}");
        
        for ($attempt = 1; $attempt <= $this->retryAttempts; $attempt++) {
            try {
                $response = Http::timeout($this->timeout)
                    ->asForm()
                    ->withHeaders([
                        'Authorization' => "Basic {$basic}",
                        'Accept' => 'application/json',
                    ])
                    ->post($url, [
                        'grant_type' => 'password',
                        'username' => $this->username,
                        'password' => $this->password,
                    ]);
                
                if ($response->successful()) {
                    $data = $response->json();
                    $token = $data['access_token'] ?? null;
                    
                    if (is_string($token) && strlen($token) > 30) {
                        Log::info('DataJuri OAuth: token obtido com sucesso');
                        return $token;
                    }
                    
                    Log::warning('DataJuri OAuth: token inválido retornado');
                }
                
                Log::warning("DataJuri OAuth attempt {$attempt} failed", [
                    'status' => $response->status(),
                    'body' => mb_substr($response->body(), 0, 500),
                ]);
                
            } catch (\Exception $e) {
                Log::error("DataJuri OAuth exception attempt {$attempt}", [
                    'error' => $e->getMessage(),
                ]);
                
                if ($attempt < $this->retryAttempts) {
                    sleep($this->retryDelay * $attempt);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Fazer requisição GET à API com retry e backoff
     */
    protected function apiGet(string $endpoint, array $params = []): ?array
    {
        $token = $this->getAccessToken();
        
        if (!$token) {
            throw new \Exception('Falha ao obter token de acesso');
        }
        
        $url = "{$this->baseUrl}{$endpoint}";
        
        for ($attempt = 1; $attempt <= $this->retryAttempts; $attempt++) {
            try {
                $response = Http::timeout($this->timeout)
                    ->withHeaders([
                        'Authorization' => "Bearer {$token}",
                    ])
                    ->get($url, $params);
                
                if ($response->status() === 401) {
                    // Token expirado, renovar e tentar novamente
                    Cache::forget('datajuri_access_token');
                    $this->accessToken = null;
                    $token = $this->getAccessToken();
                    continue;
                }
                
                if ($response->successful()) {
                    return $response->json();
                }
                
                Log::warning("DataJuri API attempt {$attempt} failed", [
                    'url' => $url,
                    'status' => $response->status(),
                    'body' => Str::limit($response->body(), 500),
                ]);
                
            } catch (\Exception $e) {
                Log::error("DataJuri API exception attempt {$attempt}", [
                    'url' => $url,
                    'error' => $e->getMessage(),
                ]);
                
                if ($attempt < $this->retryAttempts) {
                    $delay = $this->retryDelay * pow(2, $attempt - 1);
                    sleep($delay);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Descobrir módulos disponíveis na API
     */
    public function discoverModules(): array
    {
        $response = $this->apiGet('/v1/modulos');
        
        if (!$response) {
            return array_keys($this->config['modulos']);
        }
        
        return $response;
    }
    
    /**
     * Obter total de registros de um módulo
     */
    public function getModuleTotal(string $modulo): int
    {
        $config = $this->config['modulos'][$modulo] ?? null;
        
        if (!$config) {
            return 0;
        }
        
        $params = [];
        if (!empty($config['criterio'])) {
            $params['criterio'] = $config['criterio'];
        }
        
        $response = $this->apiGet("/v1/entidades/total/{$modulo}", $params);
        
        return $response['total'] ?? 0;
    }
    
    /**
     * Buscar página de entidades
     * 
     * CORREÇÃO v2.0: Removido 'removerHtml' => 'true' que QUEBRAVA a API.
     * O HTML é tratado no parseDecimal() e parseHtmlValue().
     */
    public function fetchPage(string $modulo, int $page): ?array
    {
        $config = $this->config['modulos'][$modulo] ?? null;
        
        if (!$config) {
            return null;
        }
        
        $params = [
            'page' => $page,
            'pageSize' => $this->pageSize,
            'campos' => $config['campos'],
            // CORREÇÃO: NÃO enviar removerHtml - quebra a API DataJuri
        ];
        
        // Só adicionar criterio se estiver definido
        if (!empty($config['criterio'])) {
            $params['criterio'] = $config['criterio'];
        }
        
        return $this->apiGet("/v1/entidades/{$modulo}", $params);
    }
    
    /**
     * Iniciar execução de sincronização
     */
    public function startRun(string $tipo = 'full'): string
    {
        DB::table('sync_runs')->insert([
            'run_id' => $this->runId,
            'tipo' => $tipo,
            'status' => 'running',
            'started_at' => now(),
            'modulos_processados' => json_encode([]),
            'erros_detalhados' => json_encode([]),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        
        return $this->runId;
    }
    
    /**
     * Atualizar progresso da execução
     */
    public function updateProgress(array $data): void
    {
        $data['updated_at'] = now();
        DB::table('sync_runs')
            ->where('run_id', $this->runId)
            ->update($data);
    }
    
    /**
     * Finalizar execução
     */
    public function finishRun(string $status = 'completed', ?string $mensagem = null): void
    {
        DB::table('sync_runs')
            ->where('run_id', $this->runId)
            ->update([
                'status' => $status,
                'mensagem' => $mensagem,
                'finished_at' => now(),
                'updated_at' => now(),
            ]);
    }
    
    /**
     * Obter status da execução atual
     */
    public function getRunStatus(): ?object
    {
        return DB::table('sync_runs')
            ->where('run_id', $this->runId)
            ->first();
    }
    
    /**
     * CORREÇÃO v2.0: Auto-cleanup de sync_runs stuck há mais de 30 minutos
     */
    public function cleanupStaleRuns(): int
    {
        return DB::table('sync_runs')
            ->where('status', 'running')
            ->where('started_at', '<', now()->subMinutes(30))
            ->update([
                'status' => 'failed',
                'mensagem' => 'Auto-cancelado: excedeu 30 minutos sem conclusão',
                'finished_at' => now(),
                'updated_at' => now(),
            ]);
    }
    
    /**
     * Sincronizar todos os módulos habilitados
     */
    public function syncAll(callable $progressCallback = null): array
    {
        $this->startRun('full');
        
        $results = [
            'run_id' => $this->runId,
            'modulos' => [],
            'total_processados' => 0,
            'total_criados' => 0,
            'total_atualizados' => 0,
            'total_erros' => 0,
        ];
        
        $modulosProcessados = [];
        
        try {
            foreach ($this->config['modulos'] as $modulo => $config) {
                if (!$config['enabled']) {
                    continue;
                }
                
                $this->updateProgress([
                    'modulo_atual' => $modulo,
                    'pagina_atual' => 0,
                ]);
                
                if ($progressCallback) {
                    $progressCallback($modulo, 0, 0, 'starting');
                }
                
                $result = $this->syncModule($modulo, $progressCallback);
                $results['modulos'][$modulo] = $result;
                $results['total_processados'] += $result['processados'];
                $results['total_criados'] += $result['criados'];
                $results['total_atualizados'] += $result['atualizados'];
                $results['total_erros'] += $result['erros'];
                
                $modulosProcessados[] = $modulo;
                
                $this->updateProgress([
                    'modulos_processados' => json_encode($modulosProcessados),
                    'registros_processados' => $results['total_processados'],
                    'registros_criados' => $results['total_criados'],
                    'registros_atualizados' => $results['total_atualizados'],
                    'erros' => $results['total_erros'],
                ]);
            }
            
            $this->finishRun('completed', 'Sincronização concluída com sucesso');
            
        } catch (\Exception $e) {
            $this->finishRun('failed', $e->getMessage());
            throw $e;
        }
        
        return $results;
    }
    
    /**
     * Sincronizar um módulo específico
     */
    public function syncModule(string $modulo, callable $progressCallback = null): array
    {
        $config = $this->config['modulos'][$modulo] ?? null;
        
        if (!$config) {
            throw new \Exception("Módulo {$modulo} não configurado");
        }
        
        $result = [
            'modulo' => $modulo,
            'processados' => 0,
            'criados' => 0,
            'atualizados' => 0,
            'erros' => 0,
            'paginas' => 0,
        ];
        
        $page = 1;
        $hasMore = true;
        
        while ($hasMore) {
            $response = $this->fetchPage($modulo, $page);
            
            if (!$response || empty($response['rows'])) {
                Log::warning("DataJuri syncModule: página {$page} de {$modulo} retornou vazio", [
                    'response_keys' => $response ? array_keys($response) : 'null',
                    'listSize' => $response['listSize'] ?? 'N/A',
                ]);
                $hasMore = false;
                break;
            }
            
            $totalPages = ceil(($response['listSize'] ?? 0) / $this->pageSize);
            
            Log::info("DataJuri sync: {$modulo} página {$page}/{$totalPages} - " . count($response['rows']) . " rows");
            
            $this->updateProgress([
                'pagina_atual' => $page,
                'total_paginas' => $totalPages,
            ]);
            
            if ($progressCallback) {
                $progressCallback($modulo, $page, $totalPages, 'processing');
            }
            
            // Processar página em transação
            DB::beginTransaction();
            try {
                foreach ($response['rows'] as $row) {
                    $upsertResult = $this->upsertRecord($modulo, $row, $config);
                    
                    if ($upsertResult === 'created') {
                        $result['criados']++;
                    } elseif ($upsertResult === 'updated') {
                        $result['atualizados']++;
                    }
                    
                    $result['processados']++;
                }
                
                DB::commit();
                
            } catch (\Exception $e) {
                DB::rollBack();
                $result['erros']++;
                Log::error("Erro ao processar página {$page} de {$modulo}", [
                    'error' => $e->getMessage(),
                    'trace' => Str::limit($e->getTraceAsString(), 500),
                ]);
            }
            
            $result['paginas'] = $page;
            $page++;
            
            // Verificar se há mais páginas
            if ($page > $totalPages || count($response['rows']) < $this->pageSize) {
                $hasMore = false;
            }
        }
        
        if ($progressCallback) {
            $progressCallback($modulo, $result['paginas'], $result['paginas'], 'completed');
        }
        
        return $result;
    }
    
    /**
     * Inserir ou atualizar registro com detecção de mudanças
     * 
     * CORREÇÃO v2.0: 
     * - Tratamento especial para módulo Movimento (classificação + tipo + codigo_plano)
     * - Parsing robusto de HTML nos valores monetários
     */
    protected function upsertRecord(string $modulo, array $row, array $config): string
    {
        $table = $config['table'];
        $mapping = $config['mapping'];
        $datajuriId = $row['id'] ?? null;
        
        if (!$datajuriId) {
            return 'skipped';
        }
        
        // Calcular hash do payload
        $payloadHash = hash('sha256', json_encode($row));
        
        // Verificar se registro existe
        $existing = DB::table($table)
            ->where('origem', 'datajuri')
            ->where('datajuri_id', $datajuriId)
            ->first();
        
        // Mapear campos
        $data = [
            'origem' => 'datajuri',
            'datajuri_id' => $datajuriId,
            'payload_hash' => $payloadHash,
            'payload_raw' => json_encode($row),
            'updated_at_api' => now(),
            'is_stale' => false,
            'updated_at' => now(),
        ];
        
        foreach ($mapping as $apiField => $dbField) {
            if ($dbField === 'datajuri_id') continue;
            
            $value = $this->getNestedValue($row, $apiField);
            
            // Converter valores especiais
            if (str_contains($apiField, 'data') || str_contains($apiField, 'Data')) {
                $value = $this->parseDate($value);
            } elseif (str_contains($apiField, 'valor') || str_contains($apiField, 'Valor')) {
                $value = $this->parseDecimal($value);
            }
            
            $data[$dbField] = $value;
        }
        
        // =====================================================
        // CORREÇÃO v2.0: Tratamento especial para MOVIMENTOS
        // =====================================================
        if ($modulo === 'Movimento') {
            // 1. Extrair codigo_plano do planoConta.nomeCompleto quando .codigo está vazio
            if (empty($data['codigo_plano'])) {
                $nomeCompleto = $data['plano_contas'] ?? '';
                if (preg_match('/(\d+\.\d+\.\d+\.\d+)/', $nomeCompleto, $matches)) {
                    $data['codigo_plano'] = $matches[1];
                }
            }
            
            // 2. Extrair tipo (receita/despesa) do valorComSinal HTML
            $valorComSinal = $row['valorComSinal'] ?? '';
            if (is_string($valorComSinal)) {
                if (str_contains($valorComSinal, 'valor-negativo')) {
                    $data['tipo'] = 'DESPESA';
                } elseif (str_contains($valorComSinal, 'valor-positivo')) {
                    $data['tipo'] = 'RECEITA';
                }
            }
            
            // 3. Parse do valor absoluto do valorComSinal (mais preciso que 'valor')
            $valorParsed = $this->parseHtmlValue($valorComSinal);
            if ($valorParsed !== null) {
                $data['valor'] = abs($valorParsed);
            }
            
            // 4. Extrair ano e mês da data
            if (!empty($data['data'])) {
                $dateParts = explode('-', $data['data']);
                if (count($dateParts) >= 2) {
                    $data['ano'] = (int) $dateParts[0];
                    $data['mes'] = (int) $dateParts[1];
                }
            }
            
            // 5. Classificar usando ClassificacaoService
            try {
                $classificador = new ClassificacaoService();
                $data['classificacao'] = $classificador->classificar(
                    $data['codigo_plano'] ?? null,
                    $data['tipo'] ?? null
                );
            } catch (\Exception $e) {
                // Fallback silencioso - não bloquear sync por erro de classificação
                Log::warning("Erro ao classificar movimento {$datajuriId}: " . $e->getMessage());
            }
        }
        
        if ($existing) {
            // Verificar se houve mudança
            if ($existing->payload_hash === $payloadHash) {
                // Apenas atualizar is_stale
                DB::table($table)
                    ->where('id', $existing->id)
                    ->update(['is_stale' => false, 'updated_at' => now()]);
                return 'unchanged';
            }
            
            // Atualizar registro
            DB::table($table)
                ->where('id', $existing->id)
                ->update($data);
            return 'updated';
        }
        
        // Criar novo registro
        $data['created_at'] = now();
        DB::table($table)->insert($data);
        return 'created';
    }
    
    /**
     * Obter valor aninhado de array (ex: "pessoa.nome")
     */
    protected function getNestedValue(array $data, string $key)
    {
        $keys = explode('.', $key);
        $value = $data;
        
        foreach ($keys as $k) {
            if (!is_array($value) || !isset($value[$k])) {
                return null;
            }
            $value = $value[$k];
        }
        
        return $value;
    }
    
    /**
     * Converter data brasileira para formato MySQL
     */
    protected function parseDate($value): ?string
    {
        if (empty($value)) return null;
        
        // Se já está em formato ISO (yyyy-mm-dd)
        if (preg_match('/^\d{4}-\d{2}-\d{2}/', $value)) {
            return $value;
        }
        
        // Formato: dd/mm/yyyy ou dd/mm/yyyy HH:ii
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})/', $value, $m)) {
            $date = "{$m[3]}-{$m[2]}-{$m[1]}";
            
            if (preg_match('/(\d{2}):(\d{2})/', $value, $t)) {
                $date .= " {$t[1]}:{$t[2]}:00";
            }
            
            return $date;
        }
        
        return $value;
    }
    
    /**
     * Converter valor decimal brasileiro para float
     * 
     * CORREÇÃO v2.0: Agora trata HTML do DataJuri
     * Exemplos de input:
     *   "1.234,56"
     *   "R$ 1.234,56"
     *   "<span class='valor-positivo'>1.234,56</span>"
     */
    protected function parseDecimal($value): ?float
    {
        if (empty($value)) return null;
        
        // Se for string com HTML, extrair só o número
        if (is_string($value) && str_contains($value, '<')) {
            $value = strip_tags($value);
        }
        
        // Remover R$, espaços e converter vírgula para ponto
        $value = preg_replace('/[R$\s\x{00a0}]+/u', '', $value);
        $value = str_replace('.', '', $value); // Remover separador de milhar
        $value = str_replace(',', '.', $value); // Converter vírgula decimal
        
        // Remover qualquer caractere restante que não seja número, ponto ou sinal
        $value = preg_replace('/[^0-9.\-]/', '', $value);
        
        return is_numeric($value) ? (float) $value : null;
    }
    
    /**
     * NOVO v2.0: Parse do campo valorComSinal que vem com HTML do DataJuri
     * 
     * Input:  "<span class='valor-positivo'>830,09</span>"
     * Input:  "<span class='valor-negativo'>-150,00</span>"
     * Output: 830.09 ou -150.00
     */
    protected function parseHtmlValue($value): ?float
    {
        if (empty($value) || !is_string($value)) return null;
        
        // Extrair número do HTML
        $stripped = strip_tags($value);
        
        if (empty(trim($stripped))) return null;
        
        return $this->parseDecimal($stripped);
    }
    
    /**
     * Reprocessar financeiro (full refresh com stale marking)
     */
    public function reprocessarFinanceiro(callable $progressCallback = null): array
    {
        $this->startRun('reprocessar_financeiro');
        
        $result = [
            'run_id' => $this->runId,
            'processados' => 0,
            'criados' => 0,
            'atualizados' => 0,
            'deletados' => 0,
            'erros' => 0,
        ];
        
        try {
            // Passo 1: Marcar todos os movimentos datajuri como stale
            $this->updateProgress(['mensagem' => 'Marcando registros como stale...']);
            
            DB::table('movimentos')
                ->where('origem', 'datajuri')
                ->update(['is_stale' => true]);
            
            if ($progressCallback) {
                $progressCallback('Movimento', 0, 0, 'marking_stale');
            }
            
            // Passo 2: Sincronizar todos os movimentos (upsert remove flag stale)
            $syncResult = $this->syncModule('Movimento', $progressCallback);
            
            $result['processados'] = $syncResult['processados'];
            $result['criados'] = $syncResult['criados'];
            $result['atualizados'] = $syncResult['atualizados'];
            $result['erros'] = $syncResult['erros'];
            
            // Passo 3: Deletar registros que permaneceram stale
            $this->updateProgress(['mensagem' => 'Removendo registros obsoletos...']);
            
            $deletados = DB::table('movimentos')
                ->where('origem', 'datajuri')
                ->where('is_stale', true)
                ->delete();
            
            $result['deletados'] = $deletados;
            
            if ($progressCallback) {
                $progressCallback('Movimento', 0, 0, 'cleanup_complete');
            }
            
            $this->updateProgress([
                'registros_processados' => $result['processados'],
                'registros_criados' => $result['criados'],
                'registros_atualizados' => $result['atualizados'],
                'registros_deletados' => $result['deletados'],
                'erros' => $result['erros'],
            ]);
            
            $this->finishRun('completed', "Reprocessamento concluído: {$result['deletados']} registros obsoletos removidos");
            
        } catch (\Exception $e) {
            $this->finishRun('failed', $e->getMessage());
            throw $e;
        }
        
        return $result;
    }
    
    /**
     * Smoke test da API
     */
    public function smokeTest(): array
    {
        $results = [
            'token' => false,
            'modulos' => false,
            'pessoa' => false,
            'movimento' => false,
            'errors' => [],
        ];
        
        try {
            // Teste 1: Token
            $token = $this->getAccessToken();
            $results['token'] = !empty($token);
            
            if (!$results['token']) {
                $results['errors'][] = 'Falha ao obter token OAuth';
                return $results;
            }
            
            // Teste 2: Módulos
            $modulos = $this->apiGet('/v1/modulos');
            $results['modulos'] = is_array($modulos);
            
            // Teste 3: Pessoa (1 registro para validar)
            $pessoa = $this->fetchPage('Pessoa', 1);
            $results['pessoa'] = isset($pessoa['rows']) && count($pessoa['rows']) > 0;
            $results['pessoa_count'] = $pessoa['listSize'] ?? 0;
            
            // Teste 4: Movimento (1 registro para validar)
            $movimento = $this->fetchPage('Movimento', 1);
            $results['movimento'] = isset($movimento['rows']) && count($movimento['rows']) > 0;
            $results['movimento_count'] = $movimento['listSize'] ?? 0;
            
            // Teste 5: Amostra de parsing (validar se HTML é tratado corretamente)
            if (!empty($movimento['rows'][0])) {
                $sample = $movimento['rows'][0];
                $results['sample_raw_valorComSinal'] = $sample['valorComSinal'] ?? 'N/A';
                $results['sample_parsed_valor'] = $this->parseHtmlValue($sample['valorComSinal'] ?? '');
                $results['sample_planoConta'] = $sample['planoConta']['nomeCompleto'] ?? 'N/A';
                $results['sample_codigoParsed'] = null;
                
                $nomeCompleto = $sample['planoConta']['nomeCompleto'] ?? '';
                if (preg_match('/(\d+\.\d+\.\d+\.\d+)/', $nomeCompleto, $m)) {
                    $results['sample_codigoParsed'] = $m[1];
                }
            }
            
        } catch (\Exception $e) {
            $results['errors'][] = $e->getMessage();
        }
        
        return $results;
    }
}
