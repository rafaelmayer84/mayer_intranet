<?php

return [
    'enabled' => env('ESPOCRM_ENABLED', false),
    'base_url' => env('ESPOCRM_BASE_URL', ''),
    'api_key' => env('ESPOCRM_API_KEY', ''),
];
