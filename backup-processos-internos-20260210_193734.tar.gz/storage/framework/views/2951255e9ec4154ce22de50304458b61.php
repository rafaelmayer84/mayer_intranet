<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-4 py-6">
    
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-4">Admin — Manuais Normativos</h1>
        <div class="flex space-x-2 border-b border-gray-200 dark:border-gray-700 pb-2">
            <a href="<?php echo e(route('admin.manuais.grupos.index')); ?>"
               class="px-4 py-2 text-sm font-medium rounded-t-lg bg-blue-600 text-white">Grupos</a>
            <a href="<?php echo e(route('admin.manuais.documentos.index')); ?>"
               class="px-4 py-2 text-sm font-medium rounded-t-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">Documentos</a>
            <a href="<?php echo e(route('admin.manuais.permissoes.index')); ?>"
               class="px-4 py-2 text-sm font-medium rounded-t-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">Permissões</a>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="mb-4 px-4 py-3 bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-300 rounded-lg text-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="flex justify-end mb-4">
        <a href="<?php echo e(route('admin.manuais.grupos.create')); ?>"
           class="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition">
            + Novo Grupo
        </a>
    </div>

    
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-900">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Ordem</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Nome</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Slug</th>
                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Docs</th>
                    <th class="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Ativo</th>
                    <th class="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Ações</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-750">
                        <td class="px-4 py-3 text-sm text-gray-600 dark:text-gray-300"><?php echo e($grupo->ordem); ?></td>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800 dark:text-gray-100"><?php echo e($grupo->nome); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-500 dark:text-gray-400"><?php echo e($grupo->slug); ?></td>
                        <td class="px-4 py-3 text-sm text-center text-gray-600 dark:text-gray-300"><?php echo e($grupo->documentos_count); ?></td>
                        <td class="px-4 py-3 text-center">
                            <?php if($grupo->ativo): ?>
                                <span class="inline-flex px-2 py-0.5 text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 rounded-full">Sim</span>
                            <?php else: ?>
                                <span class="inline-flex px-2 py-0.5 text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 rounded-full">Não</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-right space-x-2">
                            <a href="<?php echo e(route('admin.manuais.grupos.edit', $grupo)); ?>"
                               class="text-sm text-blue-600 dark:text-blue-400 hover:underline">Editar</a>
                            <form action="<?php echo e(route('admin.manuais.grupos.destroy', $grupo)); ?>" method="POST" class="inline"
                                  onsubmit="return confirm('Excluir grupo <?php echo e($grupo->nome); ?>? Todos os documentos serão removidos.')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-sm text-red-600 dark:text-red-400 hover:underline">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-4 py-6 text-sm text-gray-400 text-center">Nenhum grupo cadastrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-6">
        <a href="<?php echo e(route('manuais-normativos.index')); ?>" class="text-sm text-gray-500 dark:text-gray-400 hover:underline">&larr; Voltar aos Manuais</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u492856976/domains/mayeradvogados.adv.br/public_html/Intranet/resources/views/admin/manuais/grupos/index.blade.php ENDPATH**/ ?>