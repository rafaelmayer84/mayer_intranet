<?php $__env->startSection('title', 'Quadro de Avisos'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
            <h1 class="text-2xl font-semibold">Quadro de Avisos</h1>
            <?php echo $__env->make('avisos.partials.back', ['fallback' => 'home'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <p class="text-sm text-gray-600 dark:text-slate-300">Mensagens importantes e alertas do escritório.</p>
        </div>

            <div class="flex gap-2">
                <a href="<?php echo e(route('admin.avisos.index')); ?>" class="inline-flex items-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white">
                    Gerenciar
                </a>
                <a href="<?php echo e(route('admin.avisos.create')); ?>" class="inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-500">
                    Novo aviso
                </a>
            </div>
    </div>

    <?php if(session('success')): ?>
        <div class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-800 dark:border-emerald-900/40 dark:bg-emerald-900/20 dark:text-emerald-200">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-red-800 dark:border-red-900/40 dark:bg-red-900/20 dark:text-red-200">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form method="GET" action="<?php echo e(route('avisos.index')); ?>" class="rounded-xl bg-white p-4 shadow-sm dark:bg-slate-800">
        <div class="grid grid-cols-1 gap-3 md:grid-cols-4">
            <div>
                <label class="block text-xs font-semibold text-gray-600 dark:text-slate-300">Categoria</label>
                <select name="categoria_id" class="mt-1 w-full rounded-lg border-gray-200 bg-white px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:border-slate-700 dark:bg-slate-900">
                    <option value="">Todas</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php if((string)($filtros['categoria_id'] ?? '') === (string)$cat->id): echo 'selected'; endif; ?>>
                            <?php echo e($cat->nome); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-xs font-semibold text-gray-600 dark:text-slate-300">Ordenar por</label>
                <select name="ordenar" class="mt-1 w-full rounded-lg border-gray-200 bg-white px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:border-slate-700 dark:bg-slate-900">
                    <option value="prioridade" <?php if(($filtros['ordenar'] ?? 'prioridade') === 'prioridade'): echo 'selected'; endif; ?>>Prioridade</option>
                    <option value="data" <?php if(($filtros['ordenar'] ?? '') === 'data'): echo 'selected'; endif; ?>>Mais recentes</option>
                    <option value="validade" <?php if(($filtros['ordenar'] ?? '') === 'validade'): echo 'selected'; endif; ?>>Validade (mais próxima)</option>
                </select>
            </div>

            <div class="md:col-span-2">
                <label class="block text-xs font-semibold text-gray-600 dark:text-slate-300">Buscar</label>
                <div class="mt-1 flex gap-2">
                    <input name="busca" value="<?php echo e($filtros['busca'] ?? ''); ?>" class="w-full rounded-lg border-gray-200 bg-white px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:border-slate-700 dark:bg-slate-900" placeholder="Título ou descrição" />
                    <button class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white" type="submit">Filtrar</button>
                </div>
            </div>
        </div>
    </form>

    <div class="space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $avisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aviso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $cor = $aviso->getPrioridadeCorHex();
                $lidos = (int) ($aviso->usuarios_lidos_count ?? 0);
                $total = max(1, (int) $totalUsuarios);
                $pct = (int) round(($lidos / $total) * 100);
            ?>

            <div class="group rounded-xl bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:bg-slate-800">
                <div class="flex gap-4">
                    <div class="w-1.5 rounded-full" style="background: <?php echo e($cor); ?>"></div>
                    <div class="min-w-0 flex-1">
                        <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                            <div class="min-w-0">
                                <div class="flex items-center gap-2">
                                    <span class="text-lg"><?php echo e($aviso->getPrioridadeIcone()); ?></span>
                                    <h2 class="text-lg font-semibold leading-tight">
                                        <a href="<?php echo e(route('avisos.show', $aviso)); ?>" class="hover:underline">
                                            <?php echo e($aviso->titulo); ?>

                                        </a>
                                    </h2>
                                </div>

                                <div class="mt-1 flex flex-wrap items-center gap-2 text-xs text-gray-600 dark:text-slate-300">
                                    <span class="inline-flex items-center rounded-full bg-gray-100 px-2 py-0.5 dark:bg-slate-900">
                                        <?php echo e($aviso->getPrioridadeLabel()); ?>

                                    </span>
                                    <?php if($aviso->categoria): ?>
                                        <span class="inline-flex items-center rounded-full px-2 py-0.5 text-white" style="background: <?php echo e($aviso->categoria->cor_hexadecimal ?? '#3B82F6'); ?>">
                                            <?php echo e($aviso->categoria->icone ? $aviso->categoria->icone . ' ' : ''); ?><?php echo e($aviso->categoria->nome); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="text-xs text-gray-500 dark:text-slate-400">
                                <div>Criado em: <?php echo e(optional($aviso->created_at)->format('d/m/Y H:i')); ?></div>
                                <div>Válido até: <?php echo e($aviso->data_fim ? $aviso->data_fim->format('d/m/Y H:i') : '—'); ?></div>
                            </div>
                        </div>

                        <p class="mt-3 text-sm text-gray-700 dark:text-slate-200">
                            <?php echo e(\Illuminate\Support\Str::limit(strip_tags($aviso->descricao), 180)); ?>

                        </p>

                        <div class="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                            <div class="text-xs text-gray-600 dark:text-slate-300">
                                Lido por <?php echo e($lidos); ?> de <?php echo e($totalUsuarios); ?> pessoas (<?php echo e($pct); ?>%)
                            </div>
                            <a href="<?php echo e(route('avisos.show', $aviso)); ?>" class="text-sm font-semibold text-blue-600 hover:text-blue-500">Ver detalhes</a>
                        </div>

                        <div class="mt-2 h-2 w-full rounded-full bg-gray-100 dark:bg-slate-900">
                            <div class="h-2 rounded-full" style="width: <?php echo e($pct); ?>%; background: <?php echo e($cor); ?>"></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="rounded-xl border border-gray-200 bg-white p-6 text-sm text-gray-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200">
                Nenhum aviso ativo no momento.
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u492856976/domains/mayeradvogados.adv.br/public_html/Intranet/resources/views/avisos/index.blade.php ENDPATH**/ ?>