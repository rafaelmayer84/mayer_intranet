<?php
use App\Services\DashboardFinanceProdService;

$svc = app(DashboardFinanceProdService::class);

$ref = now();
$ano = (int)$ref->year;
$mes = (int)$ref->month;

// chamada indireta: vamos só registrar quando o controller chamar
logger()->info('AGING_DEBUG_NOTE', ['msg' => 'Arquivo carregado']);
