<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('advogados', function (Blueprint $table) {
            $table->id();
            $table->string('datajuri_id')->unique();
            $table->string('nome');
            $table->string('email')->nullable();
            $table->decimal('valor_hora', 10, 2)->default(0);
            $table->decimal('custo_fixo_mensal', 10, 2)->default(0);
            $table->boolean('ativo')->default(true);
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('advogados');
    }
};
