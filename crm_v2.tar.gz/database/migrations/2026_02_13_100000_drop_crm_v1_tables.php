<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Drop V1 tables in correct order (foreign keys first)
        Schema::dropIfExists('crm_events');
        Schema::dropIfExists('crm_activities');
        Schema::dropIfExists('crm_opportunities');
        Schema::dropIfExists('crm_stages');
        Schema::dropIfExists('crm_accounts');
    }

    public function down(): void
    {
        // No rollback - V1 is superseded
    }
};
